import { useState, useEffect, useRef, useCallback } from "react";

// ── Monospace + display font via Google Fonts ─────────────────────────────────
const FONT_LINK = document.createElement("link");
FONT_LINK.rel = "stylesheet";
FONT_LINK.href = "https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap";
document.head.appendChild(FONT_LINK);

// ── Theme ─────────────────────────────────────────────────────────────────────
const T = {
  bg: "#04060f",
  surface: "#080c1a",
  border: "rgba(255,255,255,0.07)",
  text: "#c8d8f0",
  muted: "#445566",
  layers: {
    input:       "#00FFD1",
    intent:      "#FFD700",
    prompt:      "#FF8C42",
    orchestrate: "#A855F7",
    evaluate:    "#4ECDC4",
    aac:         "#FF4D6D",
  }
};

// ── Layer definitions ─────────────────────────────────────────────────────────
const LAYERS = [
  { id: "input",       label: "MULTIMODAL INPUT",    icon: "◈", key: "input" },
  { id: "intent",      label: "INTENT ENGINE",       icon: "◉", key: "intent" },
  { id: "prompt",      label: "PROMPT ARCHITECT",    icon: "◇", key: "prompt" },
  { id: "orchestrate", label: "ORCHESTRATOR",        icon: "⬡", key: "orchestrate" },
  { id: "evaluate",    label: "OUTPUT EVALUATOR",    icon: "◈", key: "evaluate" },
  { id: "aac",         label: "AAC INTEGRATION",     icon: "◆", key: "aac" },
];

// ── Domain → color ────────────────────────────────────────────────────────────
const DOMAIN_COLOR = {
  NAVIGATION: "#FFD700", VEHICLE_CONTROL: "#FF4D6D",
  COMMUNICATION: "#4ECDC4", INFORMATION_QUERY: "#00FFD1",
  SYSTEM_COMMAND: "#A855F7", DOCUMENT_ANALYSIS: "#FF8C42",
  VISION_QUERY: "#4ECDC4", AUTHENTICATION: "#FF4D6D",
  EMERGENCY: "#FF0000", UNKNOWN: "#445566",
};

// ── Claude API call ───────────────────────────────────────────────────────────
async function callIAPipeline(userInput, history) {
  const systemPrompt = `You are the IA Assistant — a meta-AI middleware layer embedded in the Android Auto Commercial (AAC) Ecosystem. You operate between the human operator and all AI models.

You MUST respond with ONLY valid JSON (no markdown, no preamble, no backticks). Structure:

{
  "intent": {
    "domain": "<one of: NAVIGATION|VEHICLE_CONTROL|COMMUNICATION|INFORMATION_QUERY|SYSTEM_COMMAND|DOCUMENT_ANALYSIS|VISION_QUERY|AUTHENTICATION|EMERGENCY|UNKNOWN>",
    "priority": "<one of: CRITICAL|HIGH|NORMAL|LOW>",
    "confidence": <0.0-1.0>,
    "entities": {}
  },
  "strategy": "<one of: SINGLE_MODEL|PARALLEL_RACE|PARALLEL_CONSENSUS|FALLBACK_CHAIN>",
  "model_used": "<one of: CLAUDE_API|TFLITE_ON_DEVICE|VISION_MODEL|CODE_MODEL>",
  "response": "<your actual response to the operator — concise, vehicle-safe>",
  "confidence_score": <0.0-1.0>,
  "domain_relevance": <0.0-1.0>,
  "hallucination_flag": "<one of: NONE|SUSPECTED|DETECTED>",
  "contradiction_flag": "<one of: NONE|MINOR|MAJOR>",
  "aac_command": "<Android Intent action string, e.g. com.aac.ia.ACTION_NAVIGATION>",
  "explanation": "<brief note if confidence < 0.7, otherwise null>"
}

Rules:
- Keep responses short and scannable — vehicle context demands brevity
- Flag uncertainty explicitly via hallucination_flag
- Never fabricate vehicle sensor data
- Match domain to the operator's actual need`;

  const messages = [
    ...history.slice(-6).map(h => ({ role: h.role, content: h.content })),
    { role: "user", content: userInput }
  ];

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    })
  });

  const data = await response.json();
  const raw = data.content?.find(b => b.type === "text")?.text || "{}";
  try {
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch {
    return {
      intent: { domain: "UNKNOWN", priority: "NORMAL", confidence: 0.5, entities: {} },
      strategy: "SINGLE_MODEL", model_used: "CLAUDE_API",
      response: raw, confidence_score: 0.5, domain_relevance: 0.5,
      hallucination_flag: "NONE", contradiction_flag: "NONE",
      aac_command: "com.aac.ia.ACTION_RESPONSE", explanation: null
    };
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function genAuditId() {
  return "AUD-" + Math.random().toString(36).slice(2, 10).toUpperCase();
}
function fmt(n) { return typeof n === "number" ? n.toFixed(2) : "—"; }
function now() {
  return new Date().toLocaleTimeString("en-CA", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }) +
    "." + String(Date.now() % 1000).padStart(3, "0");
}

// ── Sub-components ────────────────────────────────────────────────────────────

function PipelineStage({ layer, state }) {
  const color = T.layers[layer.key];
  const active = state === "active";
  const done = state === "done";
  const idle = state === "idle";

  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10, padding: "8px 12px",
      border: `1px solid ${done ? color + "55" : active ? color + "88" : T.border}`,
      borderRadius: 3,
      background: active ? `${color}12` : done ? `${color}07` : "transparent",
      transition: "all 0.3s ease",
      boxShadow: active ? `0 0 12px ${color}44` : "none",
    }}>
      <div style={{
        width: 6, height: 6, borderRadius: "50%",
        background: done ? color : active ? color : T.muted,
        boxShadow: active ? `0 0 8px ${color}` : done ? `0 0 4px ${color}88` : "none",
        transition: "all 0.3s",
        animation: active ? "pulse 0.8s ease-in-out infinite" : "none",
      }} />
      <span style={{
        fontSize: 9, letterSpacing: 3, fontFamily: "'Share Tech Mono', monospace",
        color: done ? color : active ? color : T.muted,
        transition: "color 0.3s",
      }}>{layer.icon} {layer.label}</span>
      <span style={{ marginLeft: "auto", fontSize: 9, color: active ? color : done ? color + "99" : T.muted, letterSpacing: 1 }}>
        {active ? "PROCESSING" : done ? "DONE" : "STANDBY"}
      </span>
    </div>
  );
}

function ConfidenceBar({ value, color, label }) {
  const pct = Math.round((value || 0) * 100);
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
        <span style={{ fontSize: 9, letterSpacing: 2, color: T.muted }}>{label}</span>
        <span style={{ fontSize: 10, fontWeight: 700, color, letterSpacing: 1 }}>{pct}%</span>
      </div>
      <div style={{ height: 3, background: T.border, borderRadius: 2, overflow: "hidden" }}>
        <div style={{
          height: "100%", width: `${pct}%`, background: color,
          boxShadow: `0 0 6px ${color}`,
          transition: "width 0.6s cubic-bezier(0.4,0,0.2,1)",
          borderRadius: 2,
        }} />
      </div>
    </div>
  );
}

function Badge({ label, color, small }) {
  return (
    <span style={{
      display: "inline-block", padding: small ? "2px 6px" : "3px 8px",
      border: `1px solid ${color}66`, borderRadius: 2,
      fontSize: small ? 8 : 9, letterSpacing: 2,
      color, background: `${color}15`,
      fontFamily: "'Share Tech Mono', monospace",
    }}>{label}</span>
  );
}

function AuditRow({ entry }) {
  return (
    <div style={{
      display: "grid", gridTemplateColumns: "90px 110px 1fr 70px",
      gap: 8, padding: "5px 0",
      borderBottom: `1px solid ${T.border}`,
      fontSize: 9, fontFamily: "'Share Tech Mono', monospace",
    }}>
      <span style={{ color: T.muted }}>{entry.time}</span>
      <span style={{ color: DOMAIN_COLOR[entry.domain] || T.muted }}>{entry.domain}</span>
      <span style={{ color: T.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {entry.input.slice(0, 40)}{entry.input.length > 40 ? "…" : ""}
      </span>
      <span style={{ color: entry.conf > 0.7 ? T.layers.evaluate : "#FF8C42", textAlign: "right" }}>
        {fmt(entry.conf)}
      </span>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function IAPrototype() {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [pipelineStates, setPipelineStates] = useState({
    input: "idle", intent: "idle", prompt: "idle",
    orchestrate: "idle", evaluate: "idle", aac: "idle"
  });
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [auditLog, setAuditLog] = useState([]);
  const [tick, setTick] = useState(0);
  const [activeInput, setActiveInput] = useState("text");
  const inputRef = useRef(null);

  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60);
    return () => clearInterval(id);
  }, []);

  const STAGE_KEYS = ["input", "intent", "prompt", "orchestrate", "evaluate", "aac"];
  const STAGE_DELAYS = [0, 400, 800, 1200, 2200, 3000]; // ms per stage start

  const runPipeline = useCallback(async () => {
    if (!input.trim() || loading) return;
    const query = input.trim();
    setInput("");
    setLoading(true);
    setResult(null);

    // Reset all stages
    setPipelineStates({ input:"idle",intent:"idle",prompt:"idle",orchestrate:"idle",evaluate:"idle",aac:"idle" });

    // Animate stages
    const timers = STAGE_KEYS.map((key, i) =>
      setTimeout(() => {
        setPipelineStates(prev => ({ ...prev, [key]: "active" }));
        // Mark previous done
        if (i > 0) {
          const prevKey = STAGE_KEYS[i - 1];
          setPipelineStates(prev => ({ ...prev, [prevKey]: "done", [key]: "active" }));
        }
      }, STAGE_DELAYS[i])
    );

    try {
      const data = await callIAPipeline(query, history);

      // Mark all done once API returns
      setPipelineStates({ input:"done",intent:"done",prompt:"done",orchestrate:"done",evaluate:"done",aac:"done" });

      const auditId = genAuditId();
      const ts = now();

      setResult({ ...data, auditId, timestamp: ts, query });

      setHistory(h => [...h,
        { role: "user", content: query },
        { role: "assistant", content: data.response || "" }
      ].slice(-20));

      setAuditLog(log => [{
        id: auditId, time: ts,
        domain: data.intent?.domain || "UNKNOWN",
        input: query,
        conf: data.confidence_score || 0,
        model: data.model_used || "CLAUDE_API",
        cmd: data.aac_command || "—",
      }, ...log].slice(0, 20));

    } catch (e) {
      setPipelineStates({ input:"done",intent:"done",prompt:"idle",orchestrate:"idle",evaluate:"idle",aac:"idle" });
      setResult({ error: e.message, query });
    } finally {
      timers.forEach(clearTimeout);
      setLoading(false);
    }
  }, [input, loading, history]);

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); runPipeline(); }
  };

  const QUICK = [
    "Navigate to Edmonton City Hall",
    "What is the current engine temperature?",
    "Call my supervisor",
    "What's the weather on my route?",
    "Lock all vehicle doors",
    "Explain quantum computing briefly",
  ];

  const INPUT_TYPES = [
    { id: "text", icon: "T", label: "TEXT" },
    { id: "voice", icon: "♪", label: "VOICE" },
    { id: "vision", icon: "◎", label: "VISION" },
    { id: "can", icon: "⊡", label: "CAN BUS" },
    { id: "gps", icon: "◉", label: "GPS/ALE" },
    { id: "cac", icon: "▣", label: "CAC/PIV" },
  ];

  return (
    <div style={{
      minHeight: "100vh", background: T.bg,
      fontFamily: "'Share Tech Mono', monospace",
      color: T.text,
    }}>
      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        @keyframes scanline { 0%{transform:translateY(-100%)} 100%{transform:translateY(100vh)} }
        textarea:focus { outline: none; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: ${T.bg}; }
        ::-webkit-scrollbar-thumb { background: ${T.muted}; border-radius: 2px; }
        textarea { resize: none; }
      `}</style>

      {/* Scanline */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
        background: "repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,0.04) 3px,rgba(0,0,0,0.04) 4px)",
      }} />
      {/* Grid */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
        backgroundImage: `linear-gradient(${T.layers.input}08 1px,transparent 1px),linear-gradient(90deg,${T.layers.input}08 1px,transparent 1px)`,
        backgroundSize: "48px 48px",
      }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1200, margin: "0 auto", padding: "24px 16px" }}>

        {/* ── Header ── */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 28, flexWrap: "wrap", gap: 12 }}>
          <div style={{ borderLeft: `3px solid ${T.layers.input}`, paddingLeft: 16 }}>
            <div style={{ fontSize: 9, letterSpacing: 5, color: T.layers.input, opacity: 0.6, marginBottom: 4 }}>
              AAC ECOSYSTEM — LIVE PROTOTYPE
            </div>
            <h1 style={{
              margin: 0, fontFamily: "'Orbitron', sans-serif",
              fontSize: "clamp(18px,3vw,28px)", fontWeight: 900, letterSpacing: 3,
              background: `linear-gradient(90deg, #fff 0%, ${T.layers.input} 55%, ${T.layers.orchestrate} 100%)`,
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>IA ASSISTANT</h1>
            <div style={{ fontSize: 9, color: T.muted, letterSpacing: 3, marginTop: 2 }}>META-AI MIDDLEWARE LAYER</div>
          </div>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{
                width: 7, height: 7, borderRadius: "50%",
                background: T.layers.input,
                boxShadow: `0 0 ${6 + Math.sin(tick * 0.1) * 4}px ${T.layers.input}`,
              }} />
              <span style={{ fontSize: 9, color: T.layers.input, letterSpacing: 2 }}>
                {loading ? "PROCESSING" : "READY"}
              </span>
            </div>
            <div style={{ fontSize: 9, color: T.muted, letterSpacing: 1 }}>
              {auditLog.length} PROCESSED
            </div>
          </div>
        </div>

        {/* ── Main grid ── */}
        <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 16, alignItems: "start" }}>

          {/* ── Left: Pipeline ── */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ fontSize: 9, letterSpacing: 4, color: T.muted, paddingBottom: 8, borderBottom: `1px solid ${T.border}` }}>
              PIPELINE — 6 LAYERS
            </div>
            {LAYERS.map(layer => (
              <PipelineStage key={layer.id} layer={layer} state={pipelineStates[layer.key]} />
            ))}

            {/* Vehicle state mock */}
            <div style={{ marginTop: 8, padding: "12px", border: `1px solid ${T.border}`, borderRadius: 3, background: `${T.layers.aac}08` }}>
              <div style={{ fontSize: 9, letterSpacing: 3, color: T.layers.aac, marginBottom: 10 }}>VEHICLE STATE</div>
              {[
                ["SPEED", "0 km/h"], ["GEAR", "P"], ["ENGINE", "OFF"], ["FUEL", "87%"]
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                  <span style={{ fontSize: 9, color: T.muted, letterSpacing: 1 }}>{k}</span>
                  <span style={{ fontSize: 9, color: T.text }}>{v}</span>
                </div>
              ))}
            </div>

            {/* Input type selector */}
            <div style={{ padding: "12px", border: `1px solid ${T.border}`, borderRadius: 3 }}>
              <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 10 }}>INPUT TYPE</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 4 }}>
                {INPUT_TYPES.map(t => (
                  <button key={t.id} onClick={() => setActiveInput(t.id)} style={{
                    background: activeInput === t.id ? `${T.layers.input}22` : "transparent",
                    border: `1px solid ${activeInput === t.id ? T.layers.input + "88" : T.border}`,
                    borderRadius: 2, padding: "5px 4px", cursor: "pointer",
                    display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
                    opacity: t.id !== "text" ? 0.5 : 1,
                  }}>
                    <span style={{ fontSize: 12, color: activeInput === t.id ? T.layers.input : T.muted }}>{t.icon}</span>
                    <span style={{ fontSize: 7, color: activeInput === t.id ? T.layers.input : T.muted, letterSpacing: 1 }}>{t.label}</span>
                  </button>
                ))}
              </div>
              {activeInput !== "text" && (
                <div style={{ marginTop: 8, fontSize: 8, color: T.muted, letterSpacing: 1 }}>
                  {activeInput.toUpperCase()} input — use text query to simulate
                </div>
              )}
            </div>
          </div>

          {/* ── Right: Main content ── */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>

            {/* Input box */}
            <div style={{
              border: `1px solid ${loading ? T.layers.input + "66" : T.border}`,
              borderRadius: 4, overflow: "hidden",
              boxShadow: loading ? `0 0 16px ${T.layers.input}22` : "none",
              transition: "all 0.3s",
            }}>
              <div style={{ padding: "8px 14px", background: T.surface, borderBottom: `1px solid ${T.border}`, fontSize: 9, letterSpacing: 3, color: T.muted }}>
                OPERATOR INPUT — TEXT CHANNEL
              </div>
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKey}
                disabled={loading}
                placeholder="Enter query — press Enter to process through IA pipeline…"
                rows={3}
                style={{
                  width: "100%", padding: "14px", background: T.surface,
                  border: "none", color: T.text, fontSize: 12, lineHeight: 1.6,
                  fontFamily: "'Share Tech Mono', monospace",
                  boxSizing: "border-box",
                  opacity: loading ? 0.5 : 1,
                }}
              />
              <div style={{
                padding: "8px 14px", background: T.surface, borderTop: `1px solid ${T.border}`,
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <span style={{ fontSize: 9, color: T.muted }}>{input.length} CHARS | ENTER TO SEND</span>
                <button
                  onClick={runPipeline}
                  disabled={loading || !input.trim()}
                  style={{
                    background: loading ? "transparent" : `${T.layers.input}22`,
                    border: `1px solid ${loading ? T.muted : T.layers.input}`,
                    borderRadius: 2, padding: "6px 16px", cursor: loading ? "not-allowed" : "pointer",
                    color: loading ? T.muted : T.layers.input,
                    fontSize: 10, letterSpacing: 3, fontFamily: "'Share Tech Mono', monospace",
                    transition: "all 0.2s",
                  }}
                >
                  {loading ? "PROCESSING…" : "→ DISPATCH"}
                </button>
              </div>
            </div>

            {/* Quick queries */}
            <div>
              <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 8 }}>QUICK QUERIES</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {QUICK.map(q => (
                  <button key={q} onClick={() => { setInput(q); inputRef.current?.focus(); }} style={{
                    background: "transparent", border: `1px solid ${T.border}`,
                    borderRadius: 2, padding: "4px 10px", cursor: "pointer",
                    color: T.muted, fontSize: 9, letterSpacing: 1,
                    fontFamily: "'Share Tech Mono', monospace",
                    transition: "all 0.15s",
                  }}
                  onMouseEnter={e => { e.target.style.borderColor = T.layers.input + "66"; e.target.style.color = T.layers.input; }}
                  onMouseLeave={e => { e.target.style.borderColor = T.border; e.target.style.color = T.muted; }}
                  >{q}</button>
                ))}
              </div>
            </div>

            {/* Result panel */}
            {result && !result.error && (
              <div style={{
                border: `1px solid ${DOMAIN_COLOR[result.intent?.domain] || T.border}55`,
                borderRadius: 4, overflow: "hidden",
                background: `${DOMAIN_COLOR[result.intent?.domain] || T.layers.input}07`,
              }}>
                {/* Result header */}
                <div style={{
                  padding: "10px 14px", borderBottom: `1px solid ${T.border}`,
                  display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap",
                }}>
                  <Badge label={result.intent?.domain || "UNKNOWN"} color={DOMAIN_COLOR[result.intent?.domain] || T.muted} />
                  <Badge label={result.intent?.priority || "NORMAL"} color={T.layers.orchestrate} small />
                  <Badge label={result.strategy || "SINGLE"} color={T.layers.prompt} small />
                  <Badge label={result.model_used || "CLAUDE_API"} color={T.layers.evaluate} small />
                  {result.hallucination_flag !== "NONE" && (
                    <Badge label={`HALLUCINATION: ${result.hallucination_flag}`} color="#FF4D6D" />
                  )}
                  <span style={{ marginLeft: "auto", fontSize: 9, color: T.muted }}>{result.timestamp}</span>
                </div>

                {/* Response content */}
                <div style={{ padding: "16px 14px" }}>
                  <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 8 }}>IA RESPONSE</div>
                  <div style={{ fontSize: 13, lineHeight: 1.7, color: T.text }}>
                    {result.response}
                  </div>
                  {result.explanation && (
                    <div style={{ marginTop: 10, padding: "8px 10px", background: "#FF8C4215", border: `1px solid #FF8C4244`, borderRadius: 2 }}>
                      <span style={{ fontSize: 9, color: "#FF8C42", letterSpacing: 2 }}>⚠ NOTE: </span>
                      <span style={{ fontSize: 9, color: T.muted }}>{result.explanation}</span>
                    </div>
                  )}
                </div>

                {/* Metrics */}
                <div style={{ padding: "12px 14px", borderTop: `1px solid ${T.border}`, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div>
                    <ConfidenceBar value={result.confidence_score} color={T.layers.evaluate} label="CONFIDENCE" />
                    <ConfidenceBar value={result.domain_relevance} color={T.layers.intent} label="DOMAIN RELEVANCE" />
                    <ConfidenceBar value={result.intent?.confidence} color={T.layers.input} label="INTENT CONFIDENCE" />
                  </div>
                  <div>
                    <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 10 }}>EVALUATION FLAGS</div>
                    {[
                      ["HALLUCINATION", result.hallucination_flag, result.hallucination_flag === "NONE" ? T.layers.evaluate : "#FF4D6D"],
                      ["CONTRADICTION", result.contradiction_flag, result.contradiction_flag === "NONE" ? T.layers.evaluate : "#FF8C42"],
                    ].map(([k, v, c]) => (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                        <span style={{ fontSize: 9, color: T.muted, letterSpacing: 1 }}>{k}</span>
                        <Badge label={v || "NONE"} color={c} small />
                      </div>
                    ))}
                    <div style={{ marginTop: 8 }}>
                      <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 6 }}>AAC COMMAND</div>
                      <div style={{ fontSize: 9, color: T.layers.aac, wordBreak: "break-all", lineHeight: 1.5 }}>
                        {result.aac_command}
                      </div>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      <div style={{ fontSize: 9, color: T.muted, letterSpacing: 1 }}>AUDIT ID</div>
                      <div style={{ fontSize: 9, color: T.layers.orchestrate }}>{result.auditId}</div>
                    </div>
                    {result.intent?.entities && Object.keys(result.intent.entities).length > 0 && (
                      <div style={{ marginTop: 8 }}>
                        <div style={{ fontSize: 9, letterSpacing: 2, color: T.muted, marginBottom: 4 }}>ENTITIES</div>
                        {Object.entries(result.intent.entities).map(([k, v]) => (
                          <div key={k} style={{ fontSize: 9, color: T.layers.intent }}>
                            {k}: <span style={{ color: T.text }}>{v}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {result?.error && (
              <div style={{ padding: 16, border: `1px solid #FF4D6D55`, borderRadius: 4, background: "#FF4D6D08" }}>
                <span style={{ fontSize: 10, color: "#FF4D6D", letterSpacing: 2 }}>PIPELINE ERROR: </span>
                <span style={{ fontSize: 10, color: T.muted }}>{result.error}</span>
              </div>
            )}

            {/* Audit trail */}
            {auditLog.length > 0 && (
              <div style={{ border: `1px solid ${T.border}`, borderRadius: 4, overflow: "hidden" }}>
                <div style={{
                  padding: "8px 14px", background: T.surface, borderBottom: `1px solid ${T.border}`,
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                }}>
                  <span style={{ fontSize: 9, letterSpacing: 3, color: T.muted }}>AUDIT TRAIL</span>
                  <span style={{ fontSize: 9, color: T.muted }}>{auditLog.length} ENTRIES</span>
                </div>
                <div style={{ padding: "10px 14px", maxHeight: 200, overflowY: "auto" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "90px 110px 1fr 70px", gap: 8, marginBottom: 6 }}>
                    {["TIMESTAMP","DOMAIN","INPUT","CONF"].map(h => (
                      <span key={h} style={{ fontSize: 8, letterSpacing: 2, color: T.muted }}>{h}</span>
                    ))}
                  </div>
                  {auditLog.map(entry => <AuditRow key={entry.id} entry={entry} />)}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div style={{
          marginTop: 24, paddingTop: 12, borderTop: `1px solid ${T.border}`,
          display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8,
        }}>
          <span style={{ fontSize: 8, color: T.muted, letterSpacing: 3 }}>ANDROID AUTO COMMERCIAL ECOSYSTEM</span>
          <span style={{ fontSize: 8, color: T.muted, letterSpacing: 2 }}>IA ASSISTANT PROTOTYPE v0.1 — LIVE CLAUDE API</span>
        </div>
      </div>
    </div>
  );
}
