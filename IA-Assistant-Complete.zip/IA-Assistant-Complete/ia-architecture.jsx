import { useState, useEffect, useRef } from "react";

const LAYERS = [
  {
    id: "input",
    label: "01 — MULTIMODAL INPUT",
    shortLabel: "INPUT",
    color: "#00FFD1",
    glow: "0 0 20px #00FFD1aa",
    icon: "◈",
    description: "Captures all signal types from the environment and user. The IA never filters at intake — everything is accepted.",
    nodes: ["Voice / STT (Whisper on-device)", "Camera & Vision Feed", "Text & Document Streams", "AAC Sensor Bus (CAN/OBD)", "GPS / ALE Telemetry", "CAC/PIV Auth Tokens"],
    tier: "Silver+",
  },
  {
    id: "intent",
    label: "02 — INTENT & CONTEXT ENGINE",
    shortLabel: "INTENT",
    color: "#FFD700",
    glow: "0 0 20px #FFD700aa",
    icon: "◉",
    description: "Disambiguates what the user actually needs. Maintains cross-modal session state across all input channels.",
    nodes: ["Intent Classifier (BERT on-device)", "Ambiguity Resolver", "Session State Graph", "Domain Tagger", "Priority Arbiter", "Temporal Context Window"],
    tier: "Silver+",
  },
  {
    id: "prompt",
    label: "03 — PROMPT ARCHITECT",
    shortLabel: "PROMPT",
    color: "#FF6B35",
    glow: "0 0 20px #FF6B35aa",
    icon: "◇",
    description: "Constructs optimized prompts per target model. Different structure, vocabulary, and constraint sets per model family.",
    nodes: ["Claude API Template Engine", "TFLite Prompt Adapter", "Vision Model Formatter", "Context Window Manager", "Constraint Injector", "Token Budget Optimizer"],
    tier: "Magnesium+",
  },
  {
    id: "orchestrator",
    label: "04 — MODEL ORCHESTRATOR",
    shortLabel: "ORCHESTRATE",
    color: "#C77DFF",
    glow: "0 0 20px #C77DFFaa",
    icon: "⬡",
    description: "Routes, parallelizes, and races models. The intelligence of the IA lives here — knowing which model to trust for what.",
    nodes: ["Cloud Router (Claude API)", "On-Device Runner (MediaPipe/TFLite)", "Vision Specialist", "Code Model Lane", "Speech Model Lane", "Parallel Arbitration Bus"],
    tier: "Diamond+",
  },
  {
    id: "evaluator",
    label: "05 — OUTPUT EVALUATOR",
    shortLabel: "EVALUATE",
    color: "#4ECDC4",
    glow: "0 0 20px #4ECDC4aa",
    icon: "◈",
    description: "Scores every response. Synthesizes multi-model outputs into one coherent, graded answer with a confidence signature.",
    nodes: ["Confidence Scorer", "Domain Relevance Ranker", "Multi-Model Synthesizer", "Hallucination Detector", "Contradiction Flagger", "Explainability Generator"],
    tier: "Diamond+",
  },
  {
    id: "aac",
    label: "06 — AAC INTEGRATION LAYER",
    shortLabel: "AAC LAYER",
    color: "#FF4D6D",
    glow: "0 0 20px #FF4D6Daa",
    icon: "◆",
    description: "Fires Android Intents, interfaces with RT-PREEMPT kernel, enforces CAC/PIV auth. Never blocks critical vehicle processes.",
    nodes: ["Android Intent Dispatcher", "RT-PREEMPT Scheduler Interface", "CAC/PIV Auth Gateway", "System Command Bus", "ALE Location Integration", "Audit Trail Writer"],
    tier: "All Tiers",
  },
];

const TIERS = [
  { name: "Bronze", color: "#CD7F32", desc: "Voice + text, single model, cloud-only" },
  { name: "Silver", color: "#C0C0C0", desc: "Multimodal, model routing, offline fallback" },
  { name: "Magnesium", color: "#B0C4DE", desc: "Parallel orchestration, output eval, CAC auth" },
  { name: "Diamond", color: "#B9F2FF", desc: "Full meta-AI loop, domain-tuned models, audit" },
  { name: "Pure Gold", color: "#FFD700", desc: "Autonomous IA, self-correction, federated learning" },
];

const FLOW_LABELS = ["SIGNAL", "CLASSIFY", "CONSTRUCT", "ROUTE", "EVALUATE", "EXECUTE"];

function FlowParticle({ fromY, toY, color, delay }) {
  const [pos, setPos] = useState(0);
  useEffect(() => {
    const timer = setTimeout(() => {
      const interval = setInterval(() => {
        setPos(p => (p >= 1 ? 0 : p + 0.012));
      }, 16);
      return () => clearInterval(interval);
    }, delay);
    return () => clearTimeout(timer);
  }, [delay]);
  const y = fromY + (toY - fromY) * pos;
  return (
    <circle cx={50} cy={y} r={3} fill={color} opacity={0.8 - pos * 0.4}
      style={{ filter: `drop-shadow(0 0 4px ${color})` }} />
  );
}

export default function IADiagram() {
  const [active, setActive] = useState(null);
  const [hoveredTier, setHoveredTier] = useState(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 50);
    return () => clearInterval(id);
  }, []);

  const activeLayer = LAYERS.find(l => l.id === active);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#050810",
      fontFamily: "'Courier New', Courier, monospace",
      color: "#e0e8ff",
      padding: "0",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Grid background */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 0,
        backgroundImage: `
          linear-gradient(rgba(0,255,209,0.04) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0,255,209,0.04) 1px, transparent 1px)
        `,
        backgroundSize: "40px 40px",
        pointerEvents: "none",
      }} />

      {/* Scanline overlay */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 1, pointerEvents: "none",
        background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)",
      }} />

      <div style={{ position: "relative", zIndex: 2, maxWidth: 1100, margin: "0 auto", padding: "32px 16px" }}>

        {/* Header */}
        <div style={{ marginBottom: 40, borderLeft: "3px solid #00FFD1", paddingLeft: 20 }}>
          <div style={{ fontSize: 11, letterSpacing: 6, color: "#00FFD1", marginBottom: 6, opacity: 0.7 }}>
            AAC ECOSYSTEM — META-AI LAYER
          </div>
          <h1 style={{
            margin: 0, fontSize: "clamp(22px, 4vw, 38px)",
            fontWeight: 900, letterSpacing: 2,
            background: "linear-gradient(90deg, #fff 0%, #00FFD1 60%, #C77DFF 100%)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            lineHeight: 1.1,
          }}>
            IA ASSISTANT<br />
            <span style={{ fontSize: "clamp(13px, 2vw, 18px)", WebkitTextFillColor: "#8899bb", fontWeight: 400, letterSpacing: 4 }}>
              INTELLIGENT ASSISTANT ARCHITECTURE
            </span>
          </h1>
          <div style={{ marginTop: 10, fontSize: 12, color: "#556688", letterSpacing: 2 }}>
            SELECT ANY LAYER TO INSPECT ↓
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 24, alignItems: "start" }}>

          {/* Main diagram */}
          <div>
            {/* Flow connector SVG */}
            <div style={{ display: "flex", alignItems: "stretch", gap: 0 }}>

              {/* Layer column */}
              <div style={{ flex: 1 }}>
                {LAYERS.map((layer, i) => (
                  <div key={layer.id} style={{ marginBottom: 6, position: "relative" }}>
                    {/* Connector line */}
                    {i < LAYERS.length - 1 && (
                      <div style={{
                        position: "absolute", left: 28, bottom: -6, width: 2, height: 12,
                        background: `linear-gradient(${layer.color}, ${LAYERS[i + 1].color})`,
                        opacity: 0.5, zIndex: 3,
                      }} />
                    )}

                    <button
                      onClick={() => setActive(active === layer.id ? null : layer.id)}
                      style={{
                        width: "100%", background: "transparent", border: "none",
                        cursor: "pointer", padding: 0, textAlign: "left",
                      }}
                    >
                      <div style={{
                        display: "flex", alignItems: "center", gap: 0,
                        border: `1px solid ${active === layer.id ? layer.color : "rgba(255,255,255,0.07)"}`,
                        borderRadius: 4,
                        background: active === layer.id
                          ? `linear-gradient(135deg, ${layer.color}18 0%, #050810 100%)`
                          : "rgba(255,255,255,0.02)",
                        transition: "all 0.25s ease",
                        boxShadow: active === layer.id ? layer.glow : "none",
                        overflow: "hidden",
                      }}>
                        {/* Color bar */}
                        <div style={{
                          width: 4, alignSelf: "stretch", flexShrink: 0,
                          background: layer.color,
                          opacity: active === layer.id ? 1 : 0.4,
                          transition: "opacity 0.25s",
                        }} />

                        <div style={{ padding: "14px 18px", flex: 1 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                            <span style={{
                              fontSize: 18, color: layer.color,
                              filter: active === layer.id ? `drop-shadow(0 0 6px ${layer.color})` : "none",
                              transition: "filter 0.3s",
                            }}>{layer.icon}</span>
                            <span style={{
                              fontSize: 12, fontWeight: 700, letterSpacing: 3,
                              color: active === layer.id ? layer.color : "#8899bb",
                              transition: "color 0.25s",
                            }}>{layer.label}</span>
                            <span style={{
                              marginLeft: "auto", fontSize: 10, color: layer.color,
                              opacity: active === layer.id ? 1 : 0.3,
                              transition: "opacity 0.25s",
                              letterSpacing: 2,
                            }}>{FLOW_LABELS[i]}</span>
                            <span style={{
                              fontSize: 16, color: layer.color,
                              transform: active === layer.id ? "rotate(90deg)" : "rotate(0deg)",
                              transition: "transform 0.25s",
                              display: "inline-block",
                            }}>›</span>
                          </div>
                        </div>
                      </div>
                    </button>

                    {/* Expanded detail */}
                    <div style={{
                      overflow: "hidden",
                      maxHeight: active === layer.id ? 400 : 0,
                      transition: "max-height 0.4s cubic-bezier(0.4,0,0.2,1)",
                    }}>
                      <div style={{
                        margin: "4px 0 4px 4px",
                        border: `1px solid ${layer.color}33`,
                        borderRadius: 4,
                        background: `${layer.color}08`,
                        padding: "16px 20px",
                      }}>
                        <p style={{ margin: "0 0 14px", fontSize: 13, color: "#aabbcc", lineHeight: 1.7 }}>
                          {layer.description}
                        </p>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 16px" }}>
                          {layer.nodes.map((node, ni) => (
                            <div key={ni} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                              <span style={{ width: 5, height: 5, borderRadius: "50%", background: layer.color, flexShrink: 0, boxShadow: `0 0 6px ${layer.color}` }} />
                              <span style={{ fontSize: 11, color: "#8899bb", letterSpacing: 1 }}>{node}</span>
                            </div>
                          ))}
                        </div>
                        <div style={{ marginTop: 14, paddingTop: 10, borderTop: `1px solid ${layer.color}22`, display: "flex", alignItems: "center", gap: 8 }}>
                          <span style={{ fontSize: 10, color: layer.color, letterSpacing: 2 }}>AVAILABLE FROM</span>
                          <span style={{ fontSize: 11, fontWeight: 700, color: "#e0e8ff", letterSpacing: 1 }}>{layer.tier}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right panel */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

            {/* Tier legend */}
            <div style={{
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: 4, padding: "16px",
              background: "rgba(255,255,255,0.02)",
            }}>
              <div style={{ fontSize: 10, letterSpacing: 4, color: "#556688", marginBottom: 14 }}>AAC TIER CAPABILITY</div>
              {TIERS.map((tier, i) => (
                <div
                  key={tier.name}
                  onMouseEnter={() => setHoveredTier(i)}
                  onMouseLeave={() => setHoveredTier(null)}
                  style={{
                    display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 10,
                    cursor: "default", opacity: hoveredTier === null || hoveredTier === i ? 1 : 0.4,
                    transition: "opacity 0.2s",
                  }}
                >
                  <div style={{
                    width: 3, height: 38, borderRadius: 2, flexShrink: 0,
                    background: tier.color,
                    boxShadow: hoveredTier === i ? `0 0 8px ${tier.color}` : "none",
                    transition: "box-shadow 0.2s",
                    marginTop: 2,
                  }} />
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, color: tier.color }}>{tier.name.toUpperCase()}</div>
                    <div style={{ fontSize: 10, color: "#556688", lineHeight: 1.5, letterSpacing: 0.5 }}>{tier.desc}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Data flow legend */}
            <div style={{
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: 4, padding: "16px",
              background: "rgba(255,255,255,0.02)",
            }}>
              <div style={{ fontSize: 10, letterSpacing: 4, color: "#556688", marginBottom: 14 }}>META-AI FLOW</div>
              {["Before AI", "Inside AI", "After AI"].map((zone, i) => {
                const colors = ["#00FFD1", "#C77DFF", "#4ECDC4"];
                const descs = ["Intent → Prompt", "Orchestrate → Models", "Evaluate → Synthesize"];
                return (
                  <div key={zone} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                    <div style={{
                      width: 28, height: 1,
                      background: `linear-gradient(90deg, transparent, ${colors[i]})`,
                    }} />
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 700, color: colors[i], letterSpacing: 2 }}>{zone.toUpperCase()}</div>
                      <div style={{ fontSize: 10, color: "#556688" }}>{descs[i]}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pulse indicator */}
            <div style={{
              border: "1px solid rgba(0,255,209,0.15)",
              borderRadius: 4, padding: "14px 16px",
              background: "rgba(0,255,209,0.03)",
              display: "flex", alignItems: "center", gap: 12,
            }}>
              <div style={{
                width: 8, height: 8, borderRadius: "50%",
                background: "#00FFD1",
                boxShadow: `0 0 ${8 + Math.sin(tick * 0.1) * 6}px #00FFD1`,
                transition: "box-shadow 0.1s",
              }} />
              <div>
                <div style={{ fontSize: 10, letterSpacing: 2, color: "#00FFD1" }}>SYSTEM ACTIVE</div>
                <div style={{ fontSize: 9, color: "#334455", marginTop: 2 }}>RT-PREEMPT KERNEL READY</div>
              </div>
            </div>

            {/* Stats */}
            <div style={{
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: 4, padding: "14px 16px",
              background: "rgba(255,255,255,0.02)",
            }}>
              <div style={{ fontSize: 10, letterSpacing: 4, color: "#556688", marginBottom: 12 }}>ARCHITECTURE STATS</div>
              {[
                ["Layers", "6"],
                ["Model Lanes", "5"],
                ["Input Types", "6"],
                ["AAC Tiers", "5"],
                ["Auth Method", "CAC/PIV"],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 7 }}>
                  <span style={{ fontSize: 10, color: "#556688", letterSpacing: 1 }}>{k}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: "#e0e8ff", letterSpacing: 2 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          marginTop: 32, paddingTop: 16,
          borderTop: "1px solid rgba(255,255,255,0.05)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
          flexWrap: "wrap", gap: 8,
        }}>
          <span style={{ fontSize: 10, color: "#334455", letterSpacing: 3 }}>ANDROID AUTO COMMERCIAL ECOSYSTEM</span>
          <span style={{ fontSize: 10, color: "#334455", letterSpacing: 2 }}>IA ASSISTANT v0.1 — ARCHITECTURE REFERENCE</span>
        </div>
      </div>
    </div>
  );
}
