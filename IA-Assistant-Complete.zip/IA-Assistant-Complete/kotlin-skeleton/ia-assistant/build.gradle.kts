// ia-assistant/build.gradle.kts
// Android Library Module — AAC IA Assistant
// Kotlin 1.9+ | Android API 30+

plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aac.ia"
    compileSdk = 34

    defaultConfig {
        minSdk = 30                 // Android 11 — RT-PREEMPT kernel minimum
        targetSdk = 34
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            "-opt-in=kotlinx.coroutines.FlowPreview"
        )
    }
}

dependencies {
    // ── Kotlin Coroutines ─────────────────────────────────────────────────────
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")

    // ── Android Core ──────────────────────────────────────────────────────────
    implementation("androidx.core:core-ktx:1.12.0")

    // ── HTTP Client (Claude API) ───────────────────────────────────────────────
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // ── On-device ML (TFLite) — replace StubOnDeviceRunner ───────────────────
    // implementation("org.tensorflow:tensorflow-lite:2.14.0")
    // implementation("org.tensorflow:tensorflow-lite-support:0.4.4")
    // implementation("org.tensorflow:tensorflow-lite-task-text:0.4.4")

    // ── MediaPipe (vision) ────────────────────────────────────────────────────
    // implementation("com.google.mediapipe:tasks-vision:0.10.8")

    // ── JSON serialization (upgrade from stub parser) ─────────────────────────
    // implementation("com.squareup.moshi:moshi:1.15.1")
    // implementation("com.squareup.moshi:moshi-kotlin:1.15.1")

    // ── Testing ───────────────────────────────────────────────────────────────
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")
    testImplementation("io.mockk:mockk:1.13.8")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
