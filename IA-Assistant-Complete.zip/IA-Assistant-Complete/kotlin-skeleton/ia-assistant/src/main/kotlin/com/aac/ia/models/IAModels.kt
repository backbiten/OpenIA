package com.aac.ia.models

import android.graphics.Bitmap

// ─────────────────────────────────────────────
// INPUT MODELS
// ─────────────────────────────────────────────

enum class InputType {
    VOICE, TEXT, VISION, DOCUMENT, SENSOR_BUS, GPS_ALE, CAC_TOKEN
}

sealed class IAInput {
    abstract val type: InputType
    abstract val timestamp: Long

    data class VoiceInput(
        val audioBytes: ByteArray,
        val sampleRate: Int = 16000,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.VOICE }

    data class TextInput(
        val text: String,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.TEXT }

    data class VisionInput(
        val bitmap: Bitmap,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.VISION }

    data class DocumentInput(
        val rawBytes: ByteArray,
        val mimeType: String,
        val filename: String,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.DOCUMENT }

    data class SensorBusInput(
        val canFrames: List<CanFrame>,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.SENSOR_BUS }

    data class GpsAleInput(
        val latitude: Double,
        val longitude: Double,
        val accuracy: Float,
        val aleMode: AleMode,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.GPS_ALE }

    data class CacTokenInput(
        val tokenBytes: ByteArray,
        val pivSlot: PivSlot,
        override val timestamp: Long = System.currentTimeMillis()
    ) : IAInput() { override val type = InputType.CAC_TOKEN }
}

data class CanFrame(
    val id: Int,
    val data: ByteArray,
    val dlc: Int
)

enum class AleMode { HIGH_ACCURACY, BALANCED, LOW_POWER, OFF }

enum class PivSlot { PIV_AUTH, CARD_AUTH, SIGNATURE, KEY_MANAGEMENT }

// ─────────────────────────────────────────────
// INTENT MODELS
// ─────────────────────────────────────────────

enum class IntentDomain {
    NAVIGATION, VEHICLE_CONTROL, COMMUNICATION, INFORMATION_QUERY,
    SYSTEM_COMMAND, DOCUMENT_ANALYSIS, VISION_QUERY, AUTHENTICATION,
    EMERGENCY, UNKNOWN
}

enum class IntentPriority { CRITICAL, HIGH, NORMAL, LOW, BACKGROUND }

data class ClassifiedIntent(
    val domain: IntentDomain,
    val priority: IntentPriority,
    val confidence: Float,          // 0.0 – 1.0
    val rawText: String,
    val entities: Map<String, String> = emptyMap(),
    val sessionContext: SessionContext = SessionContext(),
    val requiresAuth: Boolean = false
)

data class SessionContext(
    val sessionId: String = java.util.UUID.randomUUID().toString(),
    val conversationHistory: List<HistoryEntry> = emptyList(),
    val activeInputTypes: Set<InputType> = emptySet(),
    val vehicleState: VehicleState = VehicleState()
)

data class HistoryEntry(val role: String, val content: String, val timestamp: Long = System.currentTimeMillis())

data class VehicleState(
    val speed: Float = 0f,
    val engineRunning: Boolean = false,
    val gearPosition: String = "P",
    val fuelLevel: Float = 1.0f
)

// ─────────────────────────────────────────────
// PROMPT MODELS
// ─────────────────────────────────────────────

enum class TargetModel {
    CLAUDE_API, TFLITE_ON_DEVICE, VISION_MODEL, CODE_MODEL, SPEECH_MODEL
}

data class ConstructedPrompt(
    val targetModel: TargetModel,
    val systemPrompt: String,
    val userContent: String,
    val maxTokens: Int,
    val temperature: Float,
    val metadata: PromptMetadata
)

data class PromptMetadata(
    val domain: IntentDomain,
    val estimatedTokens: Int,
    val includesVision: Boolean = false,
    val includesHistory: Boolean = false
)

// ─────────────────────────────────────────────
// ORCHESTRATION MODELS
// ─────────────────────────────────────────────

enum class OrchestrationStrategy {
    SINGLE_MODEL,           // Route to one best-fit model
    PARALLEL_RACE,          // Fire all, take fastest
    PARALLEL_CONSENSUS,     // Fire all, synthesize
    FALLBACK_CHAIN          // Try cloud → on-device → static
}

data class ModelResponse(
    val model: TargetModel,
    val content: String,
    val rawScore: Float = 1.0f,
    val latencyMs: Long,
    val tokenCount: Int = 0,
    val error: String? = null
) {
    val succeeded: Boolean get() = error == null
}

// ─────────────────────────────────────────────
// EVALUATION MODELS
// ─────────────────────────────────────────────

data class EvaluatedResponse(
    val finalContent: String,
    val confidenceScore: Float,         // 0.0 – 1.0
    val domainRelevanceScore: Float,
    val hallucination: HallucinationFlag,
    val contradiction: ContradictionFlag,
    val sourceModel: TargetModel,
    val synthesizedFrom: List<TargetModel> = emptyList(),
    val explanation: String? = null,
    val auditId: String = java.util.UUID.randomUUID().toString()
)

enum class HallucinationFlag { NONE, SUSPECTED, DETECTED }
enum class ContradictionFlag { NONE, MINOR, MAJOR }

// ─────────────────────────────────────────────
// AAC INTEGRATION MODELS
// ─────────────────────────────────────────────

data class AACCommand(
    val intentAction: String,
    val extras: Map<String, String> = emptyMap(),
    val requiresCacAuth: Boolean = false,
    val rtPreemptPriority: Int = 0     // 0 = normal, 99 = max RT priority
)

data class IAResult(
    val evaluatedResponse: EvaluatedResponse,
    val commandDispatched: AACCommand?,
    val auditEntry: AuditEntry
)

data class AuditEntry(
    val auditId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val inputTypes: List<InputType>,
    val intent: IntentDomain,
    val modelsUsed: List<TargetModel>,
    val confidenceScore: Float,
    val commandIssued: String?
)
