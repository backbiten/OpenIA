package com.aac.ia.input

import android.content.Context
import android.graphics.Bitmap
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import com.aac.ia.models.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

/**
 * MULTIMODAL INPUT LAYER
 *
 * Accepts all signal types without filtering at intake.
 * Publishes a unified IAInput stream consumed by the Intent Engine.
 *
 * AAC Tier: Silver+
 */
class MultimodalInputLayer(
    private val context: Context,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "IA:InputLayer"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private val _inputStream = MutableSharedFlow<IAInput>(
        extraBufferCapacity = 64,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )
    val inputStream: SharedFlow<IAInput> = _inputStream.asSharedFlow()

    // ── Voice capture ─────────────────────────────────────────────────────────

    private var audioRecord: AudioRecord? = null
    private var voiceJob: Job? = null

    fun startVoiceCapture() {
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBuffer == AudioRecord.ERROR_BAD_VALUE) {
            Log.e(TAG, "AudioRecord: bad buffer configuration")
            return
        }

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT,
            minBuffer * 4
        ).also { record ->
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord failed to initialize")
                return
            }
            record.startRecording()
        }

        voiceJob = scope.launch(Dispatchers.IO) {
            val buffer = ByteArray(minBuffer * 2)
            val accumulator = mutableListOf<Byte>()
            val chunkMs = 500L
            val chunkBytes = (SAMPLE_RATE * 2 * chunkMs / 1000).toInt()

            while (isActive) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: break
                if (read > 0) {
                    accumulator.addAll(buffer.take(read))
                    if (accumulator.size >= chunkBytes) {
                        val chunk = accumulator.take(chunkBytes).toByteArray()
                        accumulator.subList(0, chunkBytes).clear()
                        _inputStream.tryEmit(IAInput.VoiceInput(chunk, SAMPLE_RATE))
                    }
                }
            }
        }
        Log.i(TAG, "Voice capture started")
    }

    fun stopVoiceCapture() {
        voiceJob?.cancel()
        voiceJob = null
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        Log.i(TAG, "Voice capture stopped")
    }

    // ── Text ingestion ────────────────────────────────────────────────────────

    fun ingestText(text: String) {
        _inputStream.tryEmit(IAInput.TextInput(text))
        Log.d(TAG, "Text ingested: ${text.take(60)}…")
    }

    // ── Vision frame ──────────────────────────────────────────────────────────

    fun ingestVisionFrame(bitmap: Bitmap) {
        _inputStream.tryEmit(IAInput.VisionInput(bitmap))
        Log.d(TAG, "Vision frame ingested: ${bitmap.width}×${bitmap.height}")
    }

    // ── Document ──────────────────────────────────────────────────────────────

    fun ingestDocument(bytes: ByteArray, mimeType: String, filename: String) {
        _inputStream.tryEmit(IAInput.DocumentInput(bytes, mimeType, filename))
        Log.d(TAG, "Document ingested: $filename ($mimeType, ${bytes.size} bytes)")
    }

    // ── Sensor bus (CAN/OBD) ─────────────────────────────────────────────────

    fun ingestCanFrames(frames: List<CanFrame>) {
        if (frames.isEmpty()) return
        _inputStream.tryEmit(IAInput.SensorBusInput(frames))
        Log.d(TAG, "CAN frames ingested: ${frames.size} frames")
    }

    // ── GPS / ALE ─────────────────────────────────────────────────────────────

    fun ingestGpsAle(lat: Double, lon: Double, accuracy: Float, mode: AleMode = AleMode.BALANCED) {
        _inputStream.tryEmit(IAInput.GpsAleInput(lat, lon, accuracy, mode))
        Log.d(TAG, "ALE position ingested: lat=$lat lon=$lon mode=$mode")
    }

    // ── CAC/PIV token ─────────────────────────────────────────────────────────

    fun ingestCacToken(tokenBytes: ByteArray, slot: PivSlot = PivSlot.PIV_AUTH) {
        _inputStream.tryEmit(IAInput.CacTokenInput(tokenBytes, slot))
        Log.i(TAG, "CAC/PIV token ingested: slot=$slot")
    }

    fun teardown() {
        stopVoiceCapture()
        Log.i(TAG, "Input layer torn down")
    }
}
