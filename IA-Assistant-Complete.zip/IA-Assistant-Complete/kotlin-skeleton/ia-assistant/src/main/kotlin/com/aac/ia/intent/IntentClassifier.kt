package com.aac.ia.intent

import android.util.Log
import com.aac.ia.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * INTENT & CONTEXT ENGINE
 *
 * Disambiguates what the user actually needs.
 * Maintains cross-modal session state across all input channels.
 * Resolves ambiguity before any model sees the request.
 *
 * In production: replace rule-based classifier with a quantized
 * BERT (MobileBERT / DistilBERT) model via TFLite Interpreter.
 *
 * AAC Tier: Silver+
 */
class IntentClassifier {

    companion object {
        private const val TAG = "IA:IntentClassifier"
        private const val HIGH_CONFIDENCE = 0.85f
        private const val AMBIGUITY_THRESHOLD = 0.55f
    }

    // Active session context maintained across calls
    private var sessionContext = SessionContext()

    // ── Primary classify entry point ──────────────────────────────────────────

    suspend fun classify(inputs: List<IAInput>): ClassifiedIntent = withContext(Dispatchers.Default) {

        // 1. Build raw text representation from all inputs
        val rawText = buildRawText(inputs)
        Log.d(TAG, "Classifying: \"${rawText.take(80)}\"")

        // 2. Tag domain
        val (domain, baseConfidence) = domainClassify(rawText, inputs)

        // 3. Extract entities
        val entities = extractEntities(rawText, domain)

        // 4. Determine priority
        val priority = resolvePriority(domain, inputs)

        // 5. Determine if auth is needed
        val requiresAuth = requiresAuthentication(domain, inputs)

        // 6. Apply ambiguity penalty
        val confidence = applyAmbiguityPenalty(baseConfidence, rawText, inputs)

        // 7. Update session context
        updateSessionContext(inputs, domain, rawText)

        val intent = ClassifiedIntent(
            domain = domain,
            priority = priority,
            confidence = confidence,
            rawText = rawText,
            entities = entities,
            sessionContext = sessionContext,
            requiresAuth = requiresAuth
        )

        Log.i(TAG, "Intent → $domain [confidence=${confidence.format()}, priority=$priority]")
        intent
    }

    // ── Domain classification (rule-based stub → replace with TFLite) ─────────

    private fun domainClassify(text: String, inputs: List<IAInput>): Pair<IntentDomain, Float> {
        val lower = text.lowercase()

        // Sensor-only inputs → vehicle control
        if (inputs.all { it is IAInput.SensorBusInput }) {
            return IntentDomain.VEHICLE_CONTROL to 0.92f
        }

        // CAC token present → authentication
        if (inputs.any { it is IAInput.CacTokenInput }) {
            return IntentDomain.AUTHENTICATION to 0.98f
        }

        // Vision-only → vision query
        if (inputs.all { it is IAInput.VisionInput }) {
            return IntentDomain.VISION_QUERY to 0.88f
        }

        // Keyword-based domain scoring
        val scores = mapOf(
            IntentDomain.NAVIGATION to navigationScore(lower),
            IntentDomain.VEHICLE_CONTROL to vehicleControlScore(lower),
            IntentDomain.COMMUNICATION to communicationScore(lower),
            IntentDomain.INFORMATION_QUERY to informationScore(lower),
            IntentDomain.SYSTEM_COMMAND to systemCommandScore(lower),
            IntentDomain.DOCUMENT_ANALYSIS to documentScore(lower, inputs),
            IntentDomain.EMERGENCY to emergencyScore(lower),
        )

        val best = scores.maxByOrNull { it.value } ?: return IntentDomain.UNKNOWN to 0.3f
        return if (best.value > 0f) best.key to best.value else IntentDomain.UNKNOWN to 0.3f
    }

    private fun navigationScore(t: String) = score(t,
        high = listOf("navigate to", "directions to", "route to", "take me to", "how do i get to"),
        medium = listOf("map", "location", "nearest", "closest", "distance")
    )

    private fun vehicleControlScore(t: String) = score(t,
        high = listOf("turn on", "turn off", "engine", "ac", "heat", "defrost", "lock", "unlock"),
        medium = listOf("temperature", "fan", "wiper", "lights", "horn")
    )

    private fun communicationScore(t: String) = score(t,
        high = listOf("call", "text", "message", "send", "email", "contact"),
        medium = listOf("phone", "reply", "forward")
    )

    private fun informationScore(t: String) = score(t,
        high = listOf("what is", "who is", "explain", "tell me", "how does", "define"),
        medium = listOf("search", "find", "look up", "query")
    )

    private fun systemCommandScore(t: String) = score(t,
        high = listOf("open app", "launch", "close", "restart", "update", "install"),
        medium = listOf("settings", "volume", "brightness", "notification")
    )

    private fun documentScore(t: String, inputs: List<IAInput>) = if (
        inputs.any { it is IAInput.DocumentInput } ||
        t.contains("document") || t.contains("file") || t.contains("read this") || t.contains("summarize")
    ) 0.85f else 0f

    private fun emergencyScore(t: String) = score(t,
        high = listOf("emergency", "sos", "help me", "accident", "crash", "fire", "call 911"),
        medium = listOf("urgent", "danger", "danger")
    )

    private fun score(text: String, high: List<String>, medium: List<String>): Float {
        var s = 0f
        high.forEach { if (text.contains(it)) s += 0.85f }
        medium.forEach { if (text.contains(it)) s += 0.35f }
        return s.coerceAtMost(1.0f)
    }

    // ── Entity extraction ─────────────────────────────────────────────────────

    private fun extractEntities(text: String, domain: IntentDomain): Map<String, String> {
        val entities = mutableMapOf<String, String>()

        // Extract "to <destination>" for navigation
        Regex("(?:to|navigate to|directions to|route to)\\s+([\\w\\s,]+?)(?:\\s+from|\\s+via|$)")
            .find(text)?.groups?.get(1)?.value?.trim()?.let { entities["destination"] = it }

        // Extract contact name for communication
        if (domain == IntentDomain.COMMUNICATION) {
            Regex("(?:call|text|message)\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)?)")
                .find(text)?.groups?.get(1)?.value?.let { entities["contact"] = it }
        }

        // Extract app name for system commands
        if (domain == IntentDomain.SYSTEM_COMMAND) {
            Regex("(?:open|launch)\\s+(\\w+)")
                .find(text.lowercase())?.groups?.get(1)?.value?.let { entities["app_name"] = it }
        }

        return entities
    }

    // ── Priority resolution ───────────────────────────────────────────────────

    private fun resolvePriority(domain: IntentDomain, inputs: List<IAInput>): IntentPriority {
        return when {
            domain == IntentDomain.EMERGENCY -> IntentPriority.CRITICAL
            domain == IntentDomain.AUTHENTICATION -> IntentPriority.HIGH
            domain == IntentDomain.NAVIGATION -> IntentPriority.HIGH
            domain == IntentDomain.VEHICLE_CONTROL -> IntentPriority.HIGH
            inputs.any { it is IAInput.SensorBusInput } -> IntentPriority.HIGH
            domain == IntentDomain.COMMUNICATION -> IntentPriority.NORMAL
            else -> IntentPriority.NORMAL
        }
    }

    // ── Auth requirement ──────────────────────────────────────────────────────

    private fun requiresAuthentication(domain: IntentDomain, inputs: List<IAInput>): Boolean {
        return domain == IntentDomain.AUTHENTICATION ||
               domain == IntentDomain.SYSTEM_COMMAND ||
               inputs.any { it is IAInput.CacTokenInput }
    }

    // ── Ambiguity penalty ─────────────────────────────────────────────────────

    private fun applyAmbiguityPenalty(base: Float, text: String, inputs: List<IAInput>): Float {
        var confidence = base
        // Short text is ambiguous
        if (text.length < 10) confidence *= 0.7f
        // Multiple high-scoring domains → reduce confidence
        if (inputs.size > 3) confidence *= 0.9f
        return confidence.coerceIn(0.1f, 1.0f)
    }

    // ── Session context ───────────────────────────────────────────────────────

    private fun updateSessionContext(inputs: List<IAInput>, domain: IntentDomain, rawText: String) {
        val activeTypes = inputs.map { it.type }.toSet()
        val newEntry = HistoryEntry(role = "user", content = rawText)
        val trimmedHistory = (sessionContext.conversationHistory + newEntry).takeLast(10)

        sessionContext = sessionContext.copy(
            activeInputTypes = activeTypes,
            conversationHistory = trimmedHistory
        )
    }

    fun appendAssistantResponse(content: String) {
        val newEntry = HistoryEntry(role = "assistant", content = content)
        val trimmedHistory = (sessionContext.conversationHistory + newEntry).takeLast(10)
        sessionContext = sessionContext.copy(conversationHistory = trimmedHistory)
    }

    fun resetSession() {
        sessionContext = SessionContext()
        Log.i(TAG, "Session reset")
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun buildRawText(inputs: List<IAInput>): String {
        return inputs.joinToString(" ") { input ->
            when (input) {
                is IAInput.TextInput -> input.text
                is IAInput.VoiceInput -> "[voice:${input.audioBytes.size}b]"
                is IAInput.VisionInput -> "[vision:${input.bitmap.width}×${input.bitmap.height}]"
                is IAInput.DocumentInput -> "[doc:${input.filename}]"
                is IAInput.SensorBusInput -> "[can:${input.canFrames.size}frames]"
                is IAInput.GpsAleInput -> "[gps:${input.latitude},${input.longitude}]"
                is IAInput.CacTokenInput -> "[cac:${input.pivSlot}]"
            }
        }
    }

    private fun Float.format() = "%.2f".format(this)
}
