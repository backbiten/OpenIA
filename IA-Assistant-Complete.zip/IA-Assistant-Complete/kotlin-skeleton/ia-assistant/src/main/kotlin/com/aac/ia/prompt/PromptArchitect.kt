package com.aac.ia.prompt

import android.util.Log
import com.aac.ia.models.*

/**
 * PROMPT ARCHITECT
 *
 * Constructs optimized prompts per target model.
 * Different structure, vocabulary, and constraint sets per model family.
 * Manages token budgets and context window constraints.
 *
 * AAC Tier: Magnesium+
 */
class PromptArchitect {

    companion object {
        private const val TAG = "IA:PromptArchitect"

        // Token budget per model
        private const val CLAUDE_MAX_TOKENS = 4096
        private const val TFLITE_MAX_TOKENS = 512
        private const val CODE_MAX_TOKENS = 2048
        private const val VISION_MAX_TOKENS = 1024
        private const val SPEECH_MAX_TOKENS = 256

        // System prompt base — shared identity for all cloud calls
        private const val SYSTEM_BASE = """
You are the IA Assistant embedded within the Android Auto Commercial (AAC) Ecosystem.
You operate as a meta-AI middleware layer — your role is to reason clearly, act concisely, 
and never produce output that could distract a vehicle operator.

Rules:
- Keep responses short and scannable when vehicle is moving
- Flag uncertainty explicitly
- Never fabricate vehicle data or navigation instructions
- Respect operator authority — recommend, never command
"""
    }

    fun construct(intent: ClassifiedIntent, inputs: List<IAInput>, target: TargetModel): ConstructedPrompt {
        val prompt = when (target) {
            TargetModel.CLAUDE_API -> buildClaudePrompt(intent, inputs)
            TargetModel.TFLITE_ON_DEVICE -> buildTFLitePrompt(intent, inputs)
            TargetModel.VISION_MODEL -> buildVisionPrompt(intent, inputs)
            TargetModel.CODE_MODEL -> buildCodePrompt(intent, inputs)
            TargetModel.SPEECH_MODEL -> buildSpeechPrompt(intent, inputs)
        }
        Log.d(TAG, "Constructed prompt for $target: ~${prompt.metadata.estimatedTokens} tokens")
        return prompt
    }

    // ── Claude API ────────────────────────────────────────────────────────────

    private fun buildClaudePrompt(intent: ClassifiedIntent, inputs: List<IAInput>): ConstructedPrompt {
        val historyBlock = buildHistoryBlock(intent.sessionContext.conversationHistory)
        val contextBlock = buildVehicleContextBlock(intent.sessionContext.vehicleState)
        val entityBlock = if (intent.entities.isNotEmpty()) buildEntityBlock(intent.entities) else ""

        val systemPrompt = SYSTEM_BASE.trimIndent() + "\n\n" +
            "Domain: ${intent.domain}\n" +
            "Priority: ${intent.priority}\n" +
            contextBlock

        val userContent = buildString {
            if (entityBlock.isNotEmpty()) appendLine(entityBlock)
            if (historyBlock.isNotEmpty()) appendLine(historyBlock)
            appendLine(intent.rawText)
        }

        val estimated = estimateTokens(systemPrompt + userContent)
        val temp = when (intent.domain) {
            IntentDomain.NAVIGATION, IntentDomain.VEHICLE_CONTROL -> 0.1f
            IntentDomain.INFORMATION_QUERY -> 0.4f
            else -> 0.3f
        }

        return ConstructedPrompt(
            targetModel = TargetModel.CLAUDE_API,
            systemPrompt = systemPrompt,
            userContent = userContent,
            maxTokens = CLAUDE_MAX_TOKENS,
            temperature = temp,
            metadata = PromptMetadata(
                domain = intent.domain,
                estimatedTokens = estimated,
                includesHistory = historyBlock.isNotEmpty(),
                includesVision = inputs.any { it is IAInput.VisionInput }
            )
        )
    }

    // ── TFLite on-device ──────────────────────────────────────────────────────

    private fun buildTFLitePrompt(intent: ClassifiedIntent, inputs: List<IAInput>): ConstructedPrompt {
        // TFLite models expect lean, structured input — no elaboration
        val userContent = "[DOMAIN:${intent.domain}] [PRIORITY:${intent.priority}] ${intent.rawText}"
            .take(500) // Hard cap for on-device context window

        return ConstructedPrompt(
            targetModel = TargetModel.TFLITE_ON_DEVICE,
            systemPrompt = "", // On-device model has no system prompt
            userContent = userContent,
            maxTokens = TFLITE_MAX_TOKENS,
            temperature = 0.0f, // Deterministic on-device
            metadata = PromptMetadata(
                domain = intent.domain,
                estimatedTokens = estimateTokens(userContent)
            )
        )
    }

    // ── Vision model ──────────────────────────────────────────────────────────

    private fun buildVisionPrompt(intent: ClassifiedIntent, inputs: List<IAInput>): ConstructedPrompt {
        val visionInputs = inputs.filterIsInstance<IAInput.VisionInput>()
        val frameDesc = visionInputs.joinToString(", ") { "${it.bitmap.width}×${it.bitmap.height}" }

        val userContent = buildString {
            appendLine("Analyze the provided camera frame(s) [$frameDesc].")
            appendLine("Context: ${intent.domain} | Vehicle speed: ${intent.sessionContext.vehicleState.speed} km/h")
            if (intent.rawText.isNotBlank() && !intent.rawText.startsWith("[vision:")) {
                appendLine("Operator query: ${intent.rawText}")
            } else {
                appendLine("Describe what you see relevant to safe vehicle operation.")
            }
        }

        return ConstructedPrompt(
            targetModel = TargetModel.VISION_MODEL,
            systemPrompt = "You are a vehicle-mounted computer vision assistant. Be brief and safety-focused.",
            userContent = userContent,
            maxTokens = VISION_MAX_TOKENS,
            temperature = 0.1f,
            metadata = PromptMetadata(
                domain = intent.domain,
                estimatedTokens = estimateTokens(userContent),
                includesVision = true
            )
        )
    }

    // ── Code model ────────────────────────────────────────────────────────────

    private fun buildCodePrompt(intent: ClassifiedIntent, inputs: List<IAInput>): ConstructedPrompt {
        val docInputs = inputs.filterIsInstance<IAInput.DocumentInput>()
        val userContent = buildString {
            appendLine("Task: ${intent.rawText}")
            if (docInputs.isNotEmpty()) {
                appendLine("Files provided: ${docInputs.joinToString { it.filename }}")
            }
            appendLine("Produce clean, well-commented Kotlin/Java code compatible with Android API 30+.")
        }

        return ConstructedPrompt(
            targetModel = TargetModel.CODE_MODEL,
            systemPrompt = "You are an expert Android/Kotlin engineer. Output only compilable code with brief inline comments.",
            userContent = userContent,
            maxTokens = CODE_MAX_TOKENS,
            temperature = 0.1f,
            metadata = PromptMetadata(
                domain = intent.domain,
                estimatedTokens = estimateTokens(userContent)
            )
        )
    }

    // ── Speech model ──────────────────────────────────────────────────────────

    private fun buildSpeechPrompt(intent: ClassifiedIntent, inputs: List<IAInput>): ConstructedPrompt {
        // Speech model receives audio bytes — prompt is minimal metadata
        val voiceInputs = inputs.filterIsInstance<IAInput.VoiceInput>()
        val userContent = "[TRANSCRIBE] chunks=${voiceInputs.size} sampleRate=${voiceInputs.firstOrNull()?.sampleRate ?: 16000}"

        return ConstructedPrompt(
            targetModel = TargetModel.SPEECH_MODEL,
            systemPrompt = "",
            userContent = userContent,
            maxTokens = SPEECH_MAX_TOKENS,
            temperature = 0.0f,
            metadata = PromptMetadata(
                domain = intent.domain,
                estimatedTokens = estimateTokens(userContent)
            )
        )
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun buildHistoryBlock(history: List<HistoryEntry>): String {
        if (history.isEmpty()) return ""
        return "Conversation history:\n" + history.takeLast(4).joinToString("\n") {
            "${it.role.uppercase()}: ${it.content.take(200)}"
        }
    }

    private fun buildVehicleContextBlock(state: VehicleState): String {
        return "Vehicle state: speed=${state.speed}km/h gear=${state.gearPosition} engine=${state.engineRunning} fuel=${(state.fuelLevel * 100).toInt()}%"
    }

    private fun buildEntityBlock(entities: Map<String, String>): String {
        return "Extracted entities: " + entities.entries.joinToString(", ") { "${it.key}=${it.value}" }
    }

    // Rough token estimate: ~4 chars per token
    private fun estimateTokens(text: String): Int = (text.length / 4).coerceAtLeast(1)
}
