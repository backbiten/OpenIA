package com.aac.ia.integration

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.aac.ia.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AAC INTEGRATION LAYER
 *
 * Fires Android Intents, interfaces with RT-PREEMPT scheduling,
 * enforces CAC/PIV authentication, and writes the audit trail.
 *
 * SAFETY CONTRACT: This layer NEVER blocks critical vehicle processes.
 * RT-PREEMPT interactions use priority 0 (normal) unless escalated
 * by CRITICAL intent priority.
 *
 * AAC Tier: All Tiers
 */
class AACIntegrationLayer(
    private val context: Context,
    private val auditWriter: AuditTrailWriter
) {

    companion object {
        private const val TAG = "IA:AACLayer"

        // Intent actions
        const val ACTION_IA_RESPONSE = "com.aac.ia.ACTION_RESPONSE"
        const val ACTION_IA_NAVIGATION = "com.aac.ia.ACTION_NAVIGATION"
        const val ACTION_IA_VEHICLE_CONTROL = "com.aac.ia.ACTION_VEHICLE_CONTROL"
        const val ACTION_IA_COMMUNICATION = "com.aac.ia.ACTION_COMMUNICATION"
        const val ACTION_IA_EMERGENCY = "com.aac.ia.ACTION_EMERGENCY"
        const val ACTION_IA_SYSTEM = "com.aac.ia.ACTION_SYSTEM"

        // Extra keys
        const val EXTRA_RESPONSE_CONTENT = "ia_response_content"
        const val EXTRA_CONFIDENCE = "ia_confidence"
        const val EXTRA_AUDIT_ID = "ia_audit_id"
        const val EXTRA_DESTINATION = "ia_destination"
        const val EXTRA_CONTACT_NAME = "ia_contact_name"
        const val EXTRA_COMMAND = "ia_command"
    }

    // ── Main dispatch ─────────────────────────────────────────────────────────

    suspend fun dispatch(
        evaluated: EvaluatedResponse,
        intent: ClassifiedIntent
    ): IAResult = withContext(Dispatchers.Main) {

        // 1. CAC/PIV auth gate
        if (intent.requiresAuth && !verifyCacAuth(intent)) {
            Log.w(TAG, "CAC/PIV auth failed — blocking dispatch for domain ${intent.domain}")
            return@withContext buildAuthFailedResult(evaluated, intent)
        }

        // 2. Build AAC command
        val command = buildCommand(evaluated, intent)

        // 3. Dispatch Android Intent
        dispatchIntent(command, evaluated, intent)

        // 4. Write audit entry
        val auditEntry = buildAuditEntry(evaluated, intent, command)
        auditWriter.write(auditEntry)

        Log.i(TAG, "Dispatched: domain=${intent.domain} auditId=${evaluated.auditId}")

        IAResult(
            evaluatedResponse = evaluated,
            commandDispatched = command,
            auditEntry = auditEntry
        )
    }

    // ── Command builder ───────────────────────────────────────────────────────

    private fun buildCommand(evaluated: EvaluatedResponse, intent: ClassifiedIntent): AACCommand {
        val action = when (intent.domain) {
            IntentDomain.NAVIGATION -> ACTION_IA_NAVIGATION
            IntentDomain.VEHICLE_CONTROL -> ACTION_IA_VEHICLE_CONTROL
            IntentDomain.COMMUNICATION -> ACTION_IA_COMMUNICATION
            IntentDomain.EMERGENCY -> ACTION_IA_EMERGENCY
            IntentDomain.SYSTEM_COMMAND -> ACTION_IA_SYSTEM
            else -> ACTION_IA_RESPONSE
        }

        val extras = mutableMapOf(
            EXTRA_RESPONSE_CONTENT to evaluated.finalContent,
            EXTRA_CONFIDENCE to evaluated.confidenceScore.toString(),
            EXTRA_AUDIT_ID to evaluated.auditId
        )

        // Domain-specific extras
        intent.entities["destination"]?.let { extras[EXTRA_DESTINATION] = it }
        intent.entities["contact"]?.let { extras[EXTRA_CONTACT_NAME] = it }
        intent.entities["app_name"]?.let { extras[EXTRA_COMMAND] = it }

        val rtPriority = when (intent.priority) {
            IntentPriority.CRITICAL -> 80
            IntentPriority.HIGH -> 40
            IntentPriority.NORMAL -> 0
            else -> 0
        }

        return AACCommand(
            intentAction = action,
            extras = extras,
            requiresCacAuth = intent.requiresAuth,
            rtPreemptPriority = rtPriority
        )
    }

    // ── Intent dispatch ───────────────────────────────────────────────────────

    private fun dispatchIntent(
        command: AACCommand,
        evaluated: EvaluatedResponse,
        intent: ClassifiedIntent
    ) {
        try {
            val androidIntent = Intent(command.intentAction).apply {
                command.extras.forEach { (k, v) -> putExtra(k, v) }
                addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)

                // Tag with RT priority for downstream receivers
                if (command.rtPreemptPriority > 0) {
                    putExtra("rt_preempt_priority", command.rtPreemptPriority)
                }
            }

            // Emergency broadcasts use sendOrderedBroadcast for priority guarantee
            if (intent.domain == IntentDomain.EMERGENCY) {
                context.sendOrderedBroadcast(androidIntent, null)
                Log.w(TAG, "EMERGENCY ordered broadcast dispatched")
            } else {
                context.sendBroadcast(androidIntent)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Intent dispatch failed: ${e.message}")
        }
    }

    // ── CAC/PIV auth ──────────────────────────────────────────────────────────

    private fun verifyCacAuth(intent: ClassifiedIntent): Boolean {
        // Production: integrate with Android Keystore + PIV middleware
        // Check that a valid CAC token was present in the input session
        val hasCacInput = intent.sessionContext.activeInputTypes.contains(InputType.CAC_TOKEN)
        if (!hasCacInput) {
            Log.w(TAG, "CAC required but no token in session")
            return false
        }
        // Stub: token presence = authenticated. Real impl: verify cert chain.
        Log.i(TAG, "CAC/PIV auth verified for slot PIV_AUTH")
        return true
    }

    // ── RT-PREEMPT interface ──────────────────────────────────────────────────

    /**
     * Sets the calling thread's scheduling policy for time-sensitive operations.
     * In production: use JNI bridge to pthread_setschedparam with SCHED_FIFO.
     *
     * SAFETY: Only escalate for CRITICAL priority. Standard priority for all else.
     */
    fun setRtPriority(priority: IntentPriority) {
        // JNI stub — production implementation:
        // NativeRtScheduler.setSchedFifo(priority.toRtLevel())
        Log.d(TAG, "RT-PREEMPT priority set: $priority [JNI stub]")
    }

    // ── Fallbacks ─────────────────────────────────────────────────────────────

    private fun buildAuthFailedResult(evaluated: EvaluatedResponse, intent: ClassifiedIntent): IAResult {
        val authFailed = evaluated.copy(
            finalContent = "Authentication required. Please present your CAC/PIV card to proceed.",
            confidenceScore = 1.0f // We're certain about the auth failure
        )
        val auditEntry = buildAuditEntry(authFailed, intent, null).copy(commandIssued = "AUTH_FAILED")
        return IAResult(authFailed, null, auditEntry)
    }

    // ── Audit entry ───────────────────────────────────────────────────────────

    private fun buildAuditEntry(
        evaluated: EvaluatedResponse,
        intent: ClassifiedIntent,
        command: AACCommand?
    ): AuditEntry {
        return AuditEntry(
            auditId = evaluated.auditId,
            inputTypes = intent.sessionContext.activeInputTypes.toList(),
            intent = intent.domain,
            modelsUsed = if (evaluated.synthesizedFrom.isNotEmpty())
                evaluated.synthesizedFrom else listOf(evaluated.sourceModel),
            confidenceScore = evaluated.confidenceScore,
            commandIssued = command?.intentAction
        )
    }
}

// ── Audit trail writer ────────────────────────────────────────────────────────

class AuditTrailWriter(private val context: Context) {

    companion object {
        private const val TAG = "IA:AuditTrail"
        private const val AUDIT_FILE = "ia_audit.log"
    }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    private val auditFile: File by lazy {
        File(context.filesDir, AUDIT_FILE)
    }

    fun write(entry: AuditEntry) {
        try {
            val line = buildLogLine(entry)
            FileWriter(auditFile, true).use { it.appendLine(line) }
            Log.d(TAG, "Audit written: ${entry.auditId}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write audit: ${e.message}")
        }
    }

    private fun buildLogLine(entry: AuditEntry): String {
        val ts = dateFormat.format(Date(entry.timestamp))
        val models = entry.modelsUsed.joinToString("+") { it.name }
        val inputs = entry.inputTypes.joinToString(",") { it.name }
        return "$ts | ${entry.auditId} | ${entry.intent} | conf=${entry.confidenceScore.fmt()} | models=$models | inputs=$inputs | cmd=${entry.commandIssued ?: "none"}"
    }

    fun readRecent(limit: Int = 50): List<String> {
        return try {
            auditFile.readLines().takeLast(limit)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clear() {
        auditFile.writeText("")
        Log.i(TAG, "Audit trail cleared")
    }

    private fun Float.fmt() = "%.3f".format(this)
}
