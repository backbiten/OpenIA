package com.aac.ia.orchestrator

import android.util.Log
import com.aac.ia.models.*
import kotlinx.coroutines.*

/**
 * MODEL ORCHESTRATOR
 *
 * Routes, parallelizes, and races models.
 * Knows which model to trust for what — the intelligence of the IA.
 *
 * Strategies:
 *   SINGLE_MODEL        → one best-fit model
 *   PARALLEL_RACE       → fire all, take fastest successful
 *   PARALLEL_CONSENSUS  → fire all, synthesize results
 *   FALLBACK_CHAIN      → cloud → on-device → static
 *
 * AAC Tier: Diamond+
 */
class ModelOrchestrator(
    private val cloudRunner: CloudModelRunner,
    private val onDeviceRunner: OnDeviceModelRunner,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "IA:Orchestrator"
        private const val CLOUD_TIMEOUT_MS = 8_000L
        private const val ON_DEVICE_TIMEOUT_MS = 2_000L
    }

    // ── Strategy selection ────────────────────────────────────────────────────

    fun selectStrategy(intent: ClassifiedIntent): OrchestrationStrategy {
        return when {
            intent.priority == IntentPriority.CRITICAL -> OrchestrationStrategy.FALLBACK_CHAIN
            intent.domain == IntentDomain.VISION_QUERY -> OrchestrationStrategy.SINGLE_MODEL
            intent.domain == IntentDomain.INFORMATION_QUERY && intent.confidence > 0.8f -> OrchestrationStrategy.PARALLEL_RACE
            intent.confidence < 0.6f -> OrchestrationStrategy.PARALLEL_CONSENSUS
            else -> OrchestrationStrategy.SINGLE_MODEL
        }
    }

    fun selectModels(intent: ClassifiedIntent): List<TargetModel> {
        return when (intent.domain) {
            IntentDomain.VISION_QUERY -> listOf(TargetModel.VISION_MODEL)
            IntentDomain.INFORMATION_QUERY -> listOf(TargetModel.CLAUDE_API, TargetModel.TFLITE_ON_DEVICE)
            IntentDomain.NAVIGATION -> listOf(TargetModel.CLAUDE_API)
            IntentDomain.VEHICLE_CONTROL -> listOf(TargetModel.TFLITE_ON_DEVICE)
            IntentDomain.SYSTEM_COMMAND -> listOf(TargetModel.TFLITE_ON_DEVICE, TargetModel.CLAUDE_API)
            IntentDomain.EMERGENCY -> listOf(TargetModel.TFLITE_ON_DEVICE) // Never wait for cloud in emergency
            IntentDomain.AUTHENTICATION -> listOf(TargetModel.TFLITE_ON_DEVICE)
            else -> listOf(TargetModel.CLAUDE_API)
        }
    }

    // ── Orchestration dispatch ────────────────────────────────────────────────

    suspend fun orchestrate(
        prompts: Map<TargetModel, ConstructedPrompt>,
        strategy: OrchestrationStrategy,
        models: List<TargetModel>
    ): List<ModelResponse> = withContext(Dispatchers.IO) {

        Log.i(TAG, "Orchestrating: strategy=$strategy models=$models")

        return@withContext when (strategy) {
            OrchestrationStrategy.SINGLE_MODEL -> {
                val model = models.first()
                val prompt = prompts[model] ?: return@withContext emptyList()
                listOf(runModel(model, prompt))
            }

            OrchestrationStrategy.PARALLEL_RACE -> {
                raceModels(prompts, models)
            }

            OrchestrationStrategy.PARALLEL_CONSENSUS -> {
                runAllModels(prompts, models)
            }

            OrchestrationStrategy.FALLBACK_CHAIN -> {
                fallbackChain(prompts, models)
            }
        }
    }

    // ── Race strategy ─────────────────────────────────────────────────────────

    private suspend fun raceModels(
        prompts: Map<TargetModel, ConstructedPrompt>,
        models: List<TargetModel>
    ): List<ModelResponse> = coroutineScope {
        val resultChannel = kotlinx.coroutines.channels.Channel<ModelResponse>(models.size)

        val jobs = models.mapNotNull { model ->
            prompts[model]?.let { prompt ->
                async {
                    val response = runModel(model, prompt)
                    if (response.succeeded) resultChannel.trySend(response)
                    response
                }
            }
        }

        // Wait for first successful result
        val winner = withTimeoutOrNull(CLOUD_TIMEOUT_MS) {
            resultChannel.receive()
        }

        jobs.forEach { it.cancel() }
        resultChannel.close()

        if (winner != null) {
            Log.i(TAG, "Race won by: ${winner.model} in ${winner.latencyMs}ms")
            listOf(winner)
        } else {
            Log.w(TAG, "Race: all models failed or timed out")
            emptyList()
        }
    }

    // ── Consensus strategy ────────────────────────────────────────────────────

    private suspend fun runAllModels(
        prompts: Map<TargetModel, ConstructedPrompt>,
        models: List<TargetModel>
    ): List<ModelResponse> = coroutineScope {
        models.mapNotNull { model ->
            prompts[model]?.let { prompt ->
                async { runModel(model, prompt) }
            }
        }.awaitAll().also {
            Log.i(TAG, "Consensus: received ${it.size} responses, ${it.count { r -> r.succeeded }} succeeded")
        }
    }

    // ── Fallback chain ────────────────────────────────────────────────────────

    private suspend fun fallbackChain(
        prompts: Map<TargetModel, ConstructedPrompt>,
        models: List<TargetModel>
    ): List<ModelResponse> {
        val orderedChain = listOf(
            TargetModel.TFLITE_ON_DEVICE,
            TargetModel.CLAUDE_API,
        )

        for (model in orderedChain) {
            if (model !in models && models.isNotEmpty()) continue
            val prompt = prompts[model] ?: continue

            Log.d(TAG, "Fallback chain: trying $model")
            val response = runModel(model, prompt)
            if (response.succeeded) {
                Log.i(TAG, "Fallback chain: resolved via $model")
                return listOf(response)
            }
            Log.w(TAG, "Fallback chain: $model failed — ${response.error}")
        }

        // Static fallback for critical domains
        return listOf(staticFallback())
    }

    private fun staticFallback(): ModelResponse = ModelResponse(
        model = TargetModel.TFLITE_ON_DEVICE,
        content = "System unable to process request. Please contact operator or use manual controls.",
        rawScore = 0.1f,
        latencyMs = 0,
        error = null
    )

    // ── Model runners ─────────────────────────────────────────────────────────

    private suspend fun runModel(model: TargetModel, prompt: ConstructedPrompt): ModelResponse {
        val start = System.currentTimeMillis()
        return try {
            val timeout = if (model == TargetModel.CLAUDE_API) CLOUD_TIMEOUT_MS else ON_DEVICE_TIMEOUT_MS
            withTimeout(timeout) {
                when (model) {
                    TargetModel.CLAUDE_API -> cloudRunner.run(prompt)
                    TargetModel.TFLITE_ON_DEVICE -> onDeviceRunner.run(prompt)
                    TargetModel.VISION_MODEL -> onDeviceRunner.runVision(prompt)
                    TargetModel.CODE_MODEL -> cloudRunner.run(prompt)
                    TargetModel.SPEECH_MODEL -> onDeviceRunner.runSpeech(prompt)
                }.also {
                    Log.d(TAG, "Model $model responded in ${System.currentTimeMillis() - start}ms")
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "Model $model timed out after ${System.currentTimeMillis() - start}ms")
            ModelResponse(model, "", 0f, System.currentTimeMillis() - start, error = "timeout")
        } catch (e: Exception) {
            Log.e(TAG, "Model $model failed: ${e.message}")
            ModelResponse(model, "", 0f, System.currentTimeMillis() - start, error = e.message)
        }
    }
}

// ── Runner interfaces (implement with real clients) ───────────────────────────

interface CloudModelRunner {
    suspend fun run(prompt: ConstructedPrompt): ModelResponse
}

interface OnDeviceModelRunner {
    suspend fun run(prompt: ConstructedPrompt): ModelResponse
    suspend fun runVision(prompt: ConstructedPrompt): ModelResponse
    suspend fun runSpeech(prompt: ConstructedPrompt): ModelResponse
}

// ── Claude API runner implementation ──────────────────────────────────────────

class ClaudeApiRunner(
    private val apiKey: String,
    private val httpClient: okhttp3.OkHttpClient = okhttp3.OkHttpClient()
) : CloudModelRunner {

    companion object {
        private const val TAG = "IA:ClaudeRunner"
        private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
        private const val MODEL = "claude-sonnet-4-20250514"
    }

    override suspend fun run(prompt: ConstructedPrompt): ModelResponse =
        withContext(Dispatchers.IO) {
            val start = System.currentTimeMillis()
            try {
                val body = buildRequestBody(prompt)
                val request = okhttp3.Request.Builder()
                    .url(ENDPOINT)
                    .post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), body))
                    .addHeader("x-api-key", apiKey)
                    .addHeader("anthropic-version", "2023-06-01")
                    .addHeader("content-type", "application/json")
                    .build()

                val response = httpClient.newCall(request).execute()
                val responseBody = response.body()?.string() ?: ""

                if (!response.isSuccessful) {
                    return@withContext ModelResponse(
                        TargetModel.CLAUDE_API, "", 0f,
                        System.currentTimeMillis() - start,
                        error = "HTTP ${response.code()}: $responseBody"
                    )
                }

                val content = parseClaudeResponse(responseBody)
                ModelResponse(
                    model = TargetModel.CLAUDE_API,
                    content = content,
                    rawScore = 0.9f,
                    latencyMs = System.currentTimeMillis() - start
                )
            } catch (e: Exception) {
                Log.e(TAG, "Claude API call failed: ${e.message}")
                ModelResponse(TargetModel.CLAUDE_API, "", 0f,
                    System.currentTimeMillis() - start, error = e.message)
            }
        }

    private fun buildRequestBody(prompt: ConstructedPrompt): String {
        // Minimal JSON build without external serialization dependency
        val safeSystem = prompt.systemPrompt.replace("\"", "\\\"").replace("\n", "\\n")
        val safeUser = prompt.userContent.replace("\"", "\\\"").replace("\n", "\\n")
        return """
            {
              "model": "$MODEL",
              "max_tokens": ${prompt.maxTokens},
              "temperature": ${prompt.temperature},
              "system": "$safeSystem",
              "messages": [
                { "role": "user", "content": "$safeUser" }
              ]
            }
        """.trimIndent()
    }

    private fun parseClaudeResponse(json: String): String {
        // Lightweight parse — replace with Moshi/Gson in production
        val marker = "\"text\":\""
        val start = json.indexOf(marker)
        if (start == -1) return ""
        val contentStart = start + marker.length
        val contentEnd = json.indexOf("\"", contentStart)
        return if (contentEnd > contentStart) {
            json.substring(contentStart, contentEnd)
                .replace("\\n", "\n").replace("\\\"", "\"")
        } else ""
    }
}

// ── Stub on-device runner (replace with TFLite/MediaPipe) ────────────────────

class StubOnDeviceRunner : OnDeviceModelRunner {
    override suspend fun run(prompt: ConstructedPrompt): ModelResponse {
        delay(120) // Simulate on-device latency
        return ModelResponse(
            model = TargetModel.TFLITE_ON_DEVICE,
            content = "[ON-DEVICE STUB] Domain: ${prompt.metadata.domain} — response placeholder",
            rawScore = 0.75f,
            latencyMs = 120
        )
    }

    override suspend fun runVision(prompt: ConstructedPrompt): ModelResponse {
        delay(200)
        return ModelResponse(
            model = TargetModel.VISION_MODEL,
            content = "[VISION STUB] Frame analyzed — no anomalies detected",
            rawScore = 0.7f,
            latencyMs = 200
        )
    }

    override suspend fun runSpeech(prompt: ConstructedPrompt): ModelResponse {
        delay(80)
        return ModelResponse(
            model = TargetModel.SPEECH_MODEL,
            content = "[SPEECH STUB] Transcription placeholder",
            rawScore = 0.8f,
            latencyMs = 80
        )
    }
}
