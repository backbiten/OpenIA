package com.aac.ia.evaluator

import android.util.Log
import com.aac.ia.models.*

/**
 * OUTPUT EVALUATOR
 *
 * Scores every response for accuracy, confidence, and domain relevance.
 * Synthesizes multi-model outputs into one coherent, graded answer.
 * Flags hallucination and contradictions.
 *
 * AAC Tier: Diamond+
 */
class OutputEvaluator {

    companion object {
        private const val TAG = "IA:Evaluator"
        private const val MIN_ACCEPTABLE_SCORE = 0.4f
        private const val HALLUCINATION_SUSPICION_THRESHOLD = 0.3f
    }

    fun evaluate(
        responses: List<ModelResponse>,
        intent: ClassifiedIntent
    ): EvaluatedResponse {

        if (responses.isEmpty()) {
            return buildFallbackResponse(intent)
        }

        val successful = responses.filter { it.succeeded && it.content.isNotBlank() }
        if (successful.isEmpty()) {
            return buildFallbackResponse(intent)
        }

        return if (successful.size == 1) {
            evaluateSingle(successful.first(), intent)
        } else {
            evaluateMultiple(successful, intent)
        }
    }

    // ── Single-model evaluation ────────────────────────────────────────────────

    private fun evaluateSingle(response: ModelResponse, intent: ClassifiedIntent): EvaluatedResponse {
        val confidence = scoreConfidence(response, intent)
        val relevance = scoreDomainRelevance(response.content, intent.domain)
        val hallucination = detectHallucination(response.content, intent)
        val explanation = if (confidence < 0.6f) buildExplanation(response, confidence, relevance) else null

        Log.i(TAG, "Single eval: model=${response.model} confidence=${confidence.fmt()} relevance=${relevance.fmt()} hallucination=$hallucination")

        return EvaluatedResponse(
            finalContent = response.content,
            confidenceScore = confidence,
            domainRelevanceScore = relevance,
            hallucination = hallucination,
            contradiction = ContradictionFlag.NONE,
            sourceModel = response.model,
            explanation = explanation
        )
    }

    // ── Multi-model synthesis ─────────────────────────────────────────────────

    private fun evaluateMultiple(
        responses: List<ModelResponse>,
        intent: ClassifiedIntent
    ): EvaluatedResponse {

        // Score each response
        val scored = responses.map { r ->
            val c = scoreConfidence(r, intent)
            val rel = scoreDomainRelevance(r.content, intent.domain)
            Triple(r, c, rel)
        }

        // Detect contradictions
        val contradiction = detectContradiction(responses)
        if (contradiction == ContradictionFlag.MAJOR) {
            Log.w(TAG, "Major contradiction detected between model responses")
        }

        // Weighted synthesis: highest confidence + relevance wins anchor
        val best = scored.maxByOrNull { (_, c, rel) -> c * 0.6f + rel * 0.4f }!!
        val (bestResponse, bestConfidence, bestRelevance) = best

        // Boost confidence if multiple models agree
        val agreementBoost = if (contradiction == ContradictionFlag.NONE && responses.size > 1) 0.08f else 0f
        val finalConfidence = (bestConfidence + agreementBoost).coerceAtMost(1.0f)

        // Build synthesized content
        val synthesized = synthesizeContent(scored, bestResponse)

        val hallucination = detectHallucination(synthesized, intent)

        Log.i(TAG, "Multi-model eval: ${responses.size} sources, anchor=${bestResponse.model}, " +
            "confidence=${finalConfidence.fmt()}, contradiction=$contradiction")

        return EvaluatedResponse(
            finalContent = synthesized,
            confidenceScore = finalConfidence,
            domainRelevanceScore = bestRelevance,
            hallucination = hallucination,
            contradiction = contradiction,
            sourceModel = bestResponse.model,
            synthesizedFrom = responses.map { it.model },
            explanation = if (contradiction != ContradictionFlag.NONE)
                "Responses from ${responses.size} models showed $contradiction contradictions. Highest-confidence answer selected." else null
        )
    }

    // ── Confidence scoring ────────────────────────────────────────────────────

    private fun scoreConfidence(response: ModelResponse, intent: ClassifiedIntent): Float {
        var score = response.rawScore

        // Penalize very short responses
        val wordCount = response.content.split(" ").size
        if (wordCount < 5) score *= 0.5f

        // Reward fast on-device responses (low latency = deterministic model)
        if (response.model == TargetModel.TFLITE_ON_DEVICE && response.latencyMs < 200L) {
            score *= 1.05f
        }

        // Penalize hedge phrases
        val hedges = listOf("i'm not sure", "i don't know", "unclear", "cannot determine", "may or may not")
        val hedgeCount = hedges.count { response.content.lowercase().contains(it) }
        score -= hedgeCount * 0.08f

        // Blend with intent confidence
        score = score * 0.7f + intent.confidence * 0.3f

        return score.coerceIn(0.0f, 1.0f)
    }

    // ── Domain relevance ──────────────────────────────────────────────────────

    private fun scoreDomainRelevance(content: String, domain: IntentDomain): Float {
        val lower = content.lowercase()
        val domainKeywords = domainKeywords(domain)
        val matched = domainKeywords.count { lower.contains(it) }
        val base = if (domainKeywords.isEmpty()) 0.7f
                   else (matched.toFloat() / domainKeywords.size).coerceAtMost(1.0f)
        return base * 0.6f + 0.4f // Floor at 0.4 — presence alone implies some relevance
    }

    private fun domainKeywords(domain: IntentDomain): List<String> = when (domain) {
        IntentDomain.NAVIGATION -> listOf("route", "direction", "turn", "mile", "km", "destination", "arrive")
        IntentDomain.VEHICLE_CONTROL -> listOf("engine", "temperature", "speed", "gear", "lock", "ac", "fuel")
        IntentDomain.INFORMATION_QUERY -> listOf("answer", "result", "information", "found", "according")
        IntentDomain.COMMUNICATION -> listOf("call", "message", "sent", "contact", "phone")
        IntentDomain.EMERGENCY -> listOf("emergency", "911", "alert", "danger", "help")
        IntentDomain.AUTHENTICATION -> listOf("authenticated", "authorized", "access", "granted", "denied")
        IntentDomain.SYSTEM_COMMAND -> listOf("opened", "launched", "closed", "app", "system")
        IntentDomain.VISION_QUERY -> listOf("image", "frame", "detected", "visible", "see", "camera")
        else -> emptyList()
    }

    // ── Hallucination detection ───────────────────────────────────────────────

    private fun detectHallucination(content: String, intent: ClassifiedIntent): HallucinationFlag {
        val lower = content.lowercase()

        // Navigation hallucination: invented turn-by-turn without real data
        if (intent.domain == IntentDomain.NAVIGATION &&
            (lower.contains("turn left on") || lower.contains("turn right on")) &&
            intent.entities["destination"].isNullOrBlank()) {
            return HallucinationFlag.SUSPECTED
        }

        // Vehicle data hallucination: specific numbers without sensor input
        if (intent.domain == IntentDomain.VEHICLE_CONTROL &&
            Regex("\\b\\d+\\.\\d+\\s*(mph|km/h|rpm|psi)\\b").containsMatchIn(lower) &&
            intent.sessionContext.activeInputTypes.none { it == InputType.SENSOR_BUS }) {
            return HallucinationFlag.SUSPECTED
        }

        return HallucinationFlag.NONE
    }

    // ── Contradiction detection ───────────────────────────────────────────────

    private fun detectContradiction(responses: List<ModelResponse>): ContradictionFlag {
        if (responses.size < 2) return ContradictionFlag.NONE

        val negations = listOf("no", "not", "cannot", "won't", "unable", "impossible")
        val affirmations = listOf("yes", "can", "will", "able", "possible", "confirmed")

        var negativeCount = 0
        var affirmativeCount = 0

        responses.forEach { r ->
            val lower = r.content.lowercase()
            if (negations.any { lower.contains(it) }) negativeCount++
            if (affirmations.any { lower.contains(it) }) affirmativeCount++
        }

        return when {
            negativeCount > 0 && affirmativeCount > 0 &&
            negativeCount + affirmativeCount >= responses.size -> ContradictionFlag.MAJOR
            negativeCount > 0 && affirmativeCount > 0 -> ContradictionFlag.MINOR
            else -> ContradictionFlag.NONE
        }
    }

    // ── Content synthesis ─────────────────────────────────────────────────────

    private fun synthesizeContent(
        scored: List<Triple<ModelResponse, Float, Float>>,
        anchor: ModelResponse
    ): String {
        // For now: use the highest-scored response as anchor
        // Production: implement extractive summarization or LLM-based synthesis
        return anchor.content
    }

    // ── Fallback ──────────────────────────────────────────────────────────────

    private fun buildFallbackResponse(intent: ClassifiedIntent): EvaluatedResponse {
        Log.w(TAG, "All models failed — returning fallback for domain ${intent.domain}")
        return EvaluatedResponse(
            finalContent = "Unable to process your request at this time. Domain: ${intent.domain}. Please try again or use manual controls.",
            confidenceScore = 0.0f,
            domainRelevanceScore = 0.0f,
            hallucination = HallucinationFlag.NONE,
            contradiction = ContradictionFlag.NONE,
            sourceModel = TargetModel.TFLITE_ON_DEVICE,
            explanation = "All model runners returned errors or empty responses."
        )
    }

    private fun buildExplanation(response: ModelResponse, confidence: Float, relevance: Float): String {
        return "Low confidence answer (${confidence.fmt()}). Model: ${response.model}. " +
               "Domain relevance: ${relevance.fmt()}. Verify before acting on this response."
    }

    private fun Float.fmt() = "%.2f".format(this)
}
