package com.aac.ia.core

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.aac.ia.evaluator.OutputEvaluator
import com.aac.ia.input.MultimodalInputLayer
import com.aac.ia.integration.AACIntegrationLayer
import com.aac.ia.integration.AuditTrailWriter
import com.aac.ia.intent.IntentClassifier
import com.aac.ia.models.*
import com.aac.ia.orchestrator.ClaudeApiRunner
import com.aac.ia.orchestrator.ModelOrchestrator
import com.aac.ia.orchestrator.StubOnDeviceRunner
import com.aac.ia.prompt.PromptArchitect
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/**
 * IA ASSISTANT — MAIN COORDINATOR
 *
 * The single public facade for the entire meta-AI layer.
 * Wires together all six architectural layers:
 *
 *   MultimodalInputLayer  →  IntentClassifier  →  PromptArchitect
 *   →  ModelOrchestrator  →  OutputEvaluator   →  AACIntegrationLayer
 *
 * Usage:
 *   val ia = IAAssistant.create(context, apiKey)
 *   ia.startListening()
 *   ia.results.collect { result -> /* handle IAResult */ }
 *
 *   // Or fire a direct text query:
 *   val result = ia.query("Navigate to Edmonton City Hall")
 *
 * AAC Tier: All tiers (capability gates enforced per-layer)
 */
class IAAssistant private constructor(
    private val inputLayer: MultimodalInputLayer,
    private val intentClassifier: IntentClassifier,
    private val promptArchitect: PromptArchitect,
    private val orchestrator: ModelOrchestrator,
    private val evaluator: OutputEvaluator,
    private val aacLayer: AACIntegrationLayer,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "IA:Assistant"

        fun create(
            context: Context,
            claudeApiKey: String,
            customScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        ): IAAssistant {
            val auditWriter = AuditTrailWriter(context)
            val cloudRunner = ClaudeApiRunner(claudeApiKey)
            val onDeviceRunner = StubOnDeviceRunner() // Replace with TFLite runner

            return IAAssistant(
                inputLayer = MultimodalInputLayer(context, customScope),
                intentClassifier = IntentClassifier(),
                promptArchitect = PromptArchitect(),
                orchestrator = ModelOrchestrator(cloudRunner, onDeviceRunner, customScope),
                evaluator = OutputEvaluator(),
                aacLayer = AACIntegrationLayer(context, auditWriter),
                scope = customScope
            )
        }
    }

    // ── Result stream ─────────────────────────────────────────────────────────

    private val _results = MutableSharedFlow<IAResult>(extraBufferCapacity = 16)
    val results: SharedFlow<IAResult> = _results.asSharedFlow()

    // ── Stream-based listening mode ───────────────────────────────────────────

    fun startListening() {
        aacLayer.setRtPriority(IntentPriority.NORMAL)
        inputLayer.startVoiceCapture()

        scope.launch {
            inputLayer.inputStream
                .buffer(16)
                .collect { input ->
                    // Accumulate voice chunks into coherent batches before processing
                    if (input is IAInput.VoiceInput) {
                        // Production: buffer N chunks then flush to STT model
                        // For now: emit immediately for STT stub
                    }
                    processInputs(listOf(input))
                }
        }
        Log.i(TAG, "IA Assistant listening started")
    }

    fun stopListening() {
        inputLayer.stopVoiceCapture()
        Log.i(TAG, "IA Assistant listening stopped")
    }

    // ── Direct query API ──────────────────────────────────────────────────────

    suspend fun query(text: String): IAResult {
        val input = IAInput.TextInput(text)
        return processInputs(listOf(input))
    }

    suspend fun queryWithVision(text: String, frame: Bitmap): IAResult {
        val inputs = listOf(IAInput.TextInput(text), IAInput.VisionInput(frame))
        return processInputs(inputs)
    }

    suspend fun queryWithDocument(text: String, bytes: ByteArray, mimeType: String, filename: String): IAResult {
        val inputs = listOf(
            IAInput.TextInput(text),
            IAInput.DocumentInput(bytes, mimeType, filename)
        )
        return processInputs(inputs)
    }

    // ── Direct ingestion (non-query) ──────────────────────────────────────────

    fun ingestText(text: String) = inputLayer.ingestText(text)
    fun ingestVisionFrame(bitmap: Bitmap) = inputLayer.ingestVisionFrame(bitmap)
    fun ingestCanFrames(frames: List<CanFrame>) = inputLayer.ingestCanFrames(frames)
    fun ingestGpsAle(lat: Double, lon: Double, accuracy: Float, mode: AleMode = AleMode.BALANCED) =
        inputLayer.ingestGpsAle(lat, lon, accuracy, mode)
    fun ingestCacToken(token: ByteArray, slot: PivSlot = PivSlot.PIV_AUTH) =
        inputLayer.ingestCacToken(token, slot)

    // ── Core pipeline ─────────────────────────────────────────────────────────

    private suspend fun processInputs(inputs: List<IAInput>): IAResult {
        val pipelineStart = System.currentTimeMillis()

        return try {
            // ── Layer 2: Intent & Context Engine ──────────────────────────────
            val intent = intentClassifier.classify(inputs)
            Log.d(TAG, "Intent: ${intent.domain} [${intent.priority}] conf=${intent.confidence}")

            // ── Layer 3: Prompt Architect ──────────────────────────────────────
            val models = orchestrator.selectModels(intent)
            val strategy = orchestrator.selectStrategy(intent)
            val prompts = models.associateWith { model ->
                promptArchitect.construct(intent, inputs, model)
            }

            // ── Layer 4: Model Orchestrator ────────────────────────────────────
            aacLayer.setRtPriority(intent.priority)
            val responses = orchestrator.orchestrate(prompts, strategy, models)

            // ── Layer 5: Output Evaluator ──────────────────────────────────────
            val evaluated = evaluator.evaluate(responses, intent)

            // ── Layer 6: AAC Integration ───────────────────────────────────────
            val result = aacLayer.dispatch(evaluated, intent)

            // Update session with assistant response
            intentClassifier.appendAssistantResponse(evaluated.finalContent)

            val totalMs = System.currentTimeMillis() - pipelineStart
            Log.i(TAG, "Pipeline complete in ${totalMs}ms | conf=${evaluated.confidenceScore} | auditId=${evaluated.auditId}")

            _results.tryEmit(result)
            result

        } catch (e: Exception) {
            Log.e(TAG, "Pipeline error: ${e.message}", e)
            buildErrorResult(inputs, e)
        }
    }

    // ── Session management ────────────────────────────────────────────────────

    fun resetSession() {
        intentClassifier.resetSession()
        Log.i(TAG, "Session reset")
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    fun teardown() {
        stopListening()
        inputLayer.teardown()
        scope.cancel()
        Log.i(TAG, "IA Assistant torn down")
    }

    // ── Error result ──────────────────────────────────────────────────────────

    private fun buildErrorResult(inputs: List<IAInput>, e: Exception): IAResult {
        val errorResponse = EvaluatedResponse(
            finalContent = "IA pipeline error: ${e.message?.take(120)}",
            confidenceScore = 0f,
            domainRelevanceScore = 0f,
            hallucination = HallucinationFlag.NONE,
            contradiction = ContradictionFlag.NONE,
            sourceModel = TargetModel.TFLITE_ON_DEVICE
        )
        return IAResult(
            evaluatedResponse = errorResponse,
            commandDispatched = null,
            auditEntry = AuditEntry(
                auditId = errorResponse.auditId,
                inputTypes = inputs.map { it.type },
                intent = IntentDomain.UNKNOWN,
                modelsUsed = emptyList(),
                confidenceScore = 0f,
                commandIssued = null
            )
        )
    }
}
