# IA Assistant — AAC Meta-AI Module
**Android Auto Commercial Ecosystem | v0.1 Skeleton**

A ground-up meta-AI middleware layer for the AAC platform. The IA sits between the human operator and all AI models — governing, routing, and synthesizing intelligence before it reaches the vehicle system.

---

## Architecture

```
IAInput (Multimodal)
    │
    ▼
[L1] MultimodalInputLayer     — Voice, Text, Vision, CAN Bus, GPS/ALE, CAC/PIV
    │
    ▼
[L2] IntentClassifier         — Domain tagging, entity extraction, priority, ambiguity resolution
    │
    ▼
[L3] PromptArchitect          — Per-model prompt construction, token budgeting
    │
    ▼
[L4] ModelOrchestrator        — Strategy selection, parallel/race/fallback, timeout management
         │         │
    ClaudeAPI   TFLite/MediaPipe/Whisper
    │
    ▼
[L5] OutputEvaluator          — Confidence scoring, hallucination detection, multi-model synthesis
    │
    ▼
[L6] AACIntegrationLayer      — Intent dispatch, RT-PREEMPT scheduling, CAC/PIV gate, audit trail
    │
    ▼
IAResult → Android System / Vehicle
```

---

## Quick Start

```kotlin
// In your Activity / Fragment / Service:
val ia = IAAssistant.create(context, BuildConfig.CLAUDE_API_KEY)

// Collect results
lifecycleScope.launch {
    ia.results.collect { result ->
        val text = result.evaluatedResponse.finalContent
        val confidence = result.evaluatedResponse.confidenceScore
        Log.d("IA", "[$confidence] $text")
    }
}

// Stream mode (voice)
ia.startListening()

// Direct query
val result = ia.query("Navigate to Edmonton City Hall")

// With vision
val result = ia.queryWithVision("What's ahead?", cameraFrame)

// Inject sensor data
ia.ingestCanFrames(canFrameList)
ia.ingestGpsAle(53.5461, -113.4938, 3.5f, AleMode.BALANCED)

// Authenticated command
ia.ingestCacToken(pivTokenBytes, PivSlot.PIV_AUTH)
val result = ia.query("Open restricted system settings")

// Teardown
ia.teardown()
```

---

## Orchestration Strategies

| Strategy | When Used | Behavior |
|---|---|---|
| `SINGLE_MODEL` | High-confidence, clear domain | Best model only |
| `PARALLEL_RACE` | High confidence, time-sensitive | All models, first wins |
| `PARALLEL_CONSENSUS` | Low confidence, ambiguous | All models, synthesize |
| `FALLBACK_CHAIN` | CRITICAL priority / emergency | On-device → Cloud → Static |

---

## AAC Tier Gates

| Tier | Unlocks |
|---|---|
| Bronze | Text input, single Claude API call |
| Silver | Multimodal input, model routing, offline fallback |
| Magnesium | Parallel orchestration, output evaluation, CAC/PIV auth |
| Diamond | Full meta-AI loop, domain-tuned models, audit trail |
| Pure Gold | Autonomous IA, self-correction, federated on-device learning |

---

## Production Upgrade Path

| Stub | Replace With |
|---|---|
| `StubOnDeviceRunner` | TFLite Interpreter + MobileBERT model |
| Voice accumulation | Whisper on-device (OpenAI Whisper.tflite) |
| Vision model | MediaPipe Tasks (ObjectDetection / ImageClassification) |
| Stub JSON parser | Moshi or kotlinx.serialization |
| RT-PREEMPT JNI stub | `NativeRtScheduler` via CMake + pthread_setschedparam |
| CAC stub | Android Keystore + PIV middleware (YubiKit Android SDK) |

---

## File Structure

```
ia-assistant/
├── build.gradle.kts
└── src/main/kotlin/com/aac/ia/
    ├── core/
    │   └── IAAssistant.kt          ← Main facade — start here
    ├── input/
    │   └── MultimodalInputLayer.kt
    ├── intent/
    │   └── IntentClassifier.kt
    ├── prompt/
    │   └── PromptArchitect.kt
    ├── orchestrator/
    │   └── ModelOrchestrator.kt    ← ClaudeApiRunner + StubOnDeviceRunner
    ├── evaluator/
    │   └── OutputEvaluator.kt
    ├── integration/
    │   └── AACIntegrationLayer.kt  ← AuditTrailWriter here too
    └── models/
        └── IAModels.kt             ← All data classes & enums
```

---

*Android Auto Commercial Ecosystem — IA Assistant v0.1*
