import { useState, useEffect } from "react";

const FONT = document.createElement("link");
FONT.rel = "stylesheet";
FONT.href = "https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap";
document.head.appendChild(FONT);

// ── Palette ───────────────────────────────────────────────────────────────────
const T = {
  bg: "#03050e",
  surface: "#070a18",
  border: "rgba(255,255,255,0.06)",
  text: "#c8d8f0",
  muted: "#3a4f66",
  ia: {
    input:       { color: "#00FFD1", label: "01", name: "MULTIMODAL INPUT" },
    intent:      { color: "#FFD700", label: "02", name: "INTENT ENGINE" },
    prompt:      { color: "#FF8C42", label: "03", name: "PROMPT ARCHITECT" },
    orchestrate: { color: "#A855F7", label: "04", name: "MODEL ORCHESTRATOR" },
    evaluate:    { color: "#4ECDC4", label: "05", name: "OUTPUT EVALUATOR" },
    aac:         { color: "#FF4D6D", label: "06", name: "AAC INTEGRATION" },
  },
  time: "#FF2D78",
  timeGlow: "0 0 24px #FF2D7888",
};

// TIME knowledge pillars
const TIME_PILLARS = [
  {
    id: "profiles",
    label: "HISTORICAL PLATFORM PROFILES",
    color: "#FF6B9D",
    icon: "⊞",
    entries: [
      "32-bit x86 — DOS/Win 9x/ME era",
      "32-bit x86 — Win NT/2000/XP/Vista",
      "64-bit x86-64 — Win 7/8/8.1/10/11",
      "PowerPC — macOS 10.0–10.5",
      "Intel Mac — macOS 10.6–13",
      "Apple Silicon — macOS 14+",
      "Linux i386/i686 — kernel 2.4–3.x",
      "Linux x86-64 — kernel 4.x–6.x",
      "Linux ARM — embedded/IoT/Android",
      "BSD variants — FreeBSD, OpenBSD",
      "Legacy BIOS / UEFI profiles",
      "Driver ecosystem fingerprints per era",
    ],
  },
  {
    id: "malware",
    label: "MALWARE TAXONOMY DATABASE",
    color: "#FF4D6D",
    icon: "◈",
    entries: [
      "Boot sector / MBR viruses (1980s–)",
      "File infectors — COM, EXE, PE32",
      "Macro viruses — Office, PDF",
      "Worms — network propagation lineage",
      "Trojans — RATs, keyloggers, backdoors",
      "Rootkits — kernel, hypervisor, UEFI",
      "Ransomware families — 2013–present",
      "Fileless malware — in-memory only",
      "macOS adware / spyware families",
      "Linux rootkits + cryptominers",
      "Cross-platform malware lineages",
      "APT toolkits — nation-state attributed",
    ],
  },
  {
    id: "behavioral",
    label: "BEHAVIORAL SIGNATURE PATTERNS",
    color: "#FF8C42",
    icon: "◉",
    entries: [
      "API call sequences — Win32/NT native",
      "Registry mutation patterns",
      "File system anomaly trees",
      "Network traffic fingerprints",
      "Process injection techniques",
      "Privilege escalation chains",
      "Persistence mechanism patterns",
      "Exfiltration channel signatures",
      "Encryption routine fingerprints",
      "Anti-analysis evasion patterns",
      "Lateral movement indicators",
      "C2 beacon timing signatures",
    ],
  },
];

// IA layers with TIME integration points
const IA_LAYERS = [
  {
    key: "input", label: "01 — MULTIMODAL INPUT", color: T.ia.input.color,
    timeIntegration: "New input types: file hashes, process tree snapshots, system profile dumps, PE header bytes, memory dumps",
    timeActive: true,
  },
  {
    key: "intent", label: "02 — INTENT ENGINE", color: T.ia.intent.color,
    timeIntegration: "New domains: SECURITY_THREAT, ANOMALY_DETECTION, MALWARE_QUERY, SYSTEM_AUDIT. TIME domain gets CRITICAL priority override.",
    timeActive: true,
  },
  {
    key: "prompt", label: "03 — PROMPT ARCHITECT", color: T.ia.prompt.color,
    timeIntegration: "Injects TIME threat context into all prompts when threat_score > 0.3. Builds specialized forensic prompt templates.",
    timeActive: true,
  },
  {
    key: "orchestrate", label: "04 — MODEL ORCHESTRATOR", color: T.ia.orchestrate.color,
    timeIntegration: "TIME MODEL is a new dedicated model lane. Runs in parallel with cloud and on-device lanes. Always FALLBACK_CHAIN for SECURITY_THREAT domain.",
    timeActive: true,
    isTimeLane: true,
  },
  {
    key: "evaluate", label: "05 — OUTPUT EVALUATOR", color: T.ia.evaluate.color,
    timeIntegration: "New scoring dimension: threat_score (0.0–1.0). TIME findings override confidence floor. DETECTED hallucinations auto-flagged on threat responses.",
    timeActive: true,
  },
  {
    key: "aac", label: "06 — AAC INTEGRATION", color: T.ia.aac.color,
    timeIntegration: "New Intent action: com.aac.ia.ACTION_SECURITY_ALERT. CRITICAL threat_score triggers ordered broadcast bypass of normal dispatch queue.",
    timeActive: false,
  },
];

// TIME model lanes
const MODEL_LANES = [
  { label: "CLAUDE API", color: "#A855F7", active: true },
  { label: "TFLITE ON-DEVICE", color: "#00FFD1", active: true },
  { label: "VISION MODEL", color: "#4ECDC4", active: true },
  { label: "TIME ENGINE", color: "#FF2D78", active: true, isTime: true },
  { label: "CODE MODEL", color: "#FF8C42", active: true },
];

// ── Sub-components ────────────────────────────────────────────────────────────

function LayerRow({ layer, selected, onSelect, tick }) {
  const isSelected = selected === layer.key;
  const c = layer.color;

  return (
    <div style={{ marginBottom: 5 }}>
      <button
        onClick={() => onSelect(isSelected ? null : layer.key)}
        style={{ width: "100%", background: "transparent", border: "none", padding: 0, cursor: "pointer", textAlign: "left" }}
      >
        <div style={{
          display: "flex", alignItems: "center", gap: 0,
          border: `1px solid ${isSelected ? c + "88" : T.border}`,
          borderRadius: 3,
          background: isSelected ? `${c}10` : "rgba(255,255,255,0.01)",
          boxShadow: isSelected ? `0 0 10px ${c}33` : "none",
          transition: "all 0.25s",
          overflow: "hidden",
          position: "relative",
        }}>
          {/* Left accent */}
          <div style={{ width: 3, alignSelf: "stretch", background: c, opacity: isSelected ? 1 : 0.3, flexShrink: 0, transition: "opacity 0.25s" }} />

          <div style={{ flex: 1, padding: "10px 14px", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 10, letterSpacing: 3, color: isSelected ? c : T.muted, fontFamily: "'Share Tech Mono', monospace", transition: "color 0.25s" }}>
              {layer.label}
            </span>
            {/* TIME badge */}
            {layer.timeActive && (
              <span style={{
                marginLeft: "auto", fontSize: 8, letterSpacing: 2, padding: "2px 6px",
                border: `1px solid ${T.time}55`,
                background: `${T.time}15`,
                borderRadius: 2,
                color: T.time,
                fontFamily: "'Share Tech Mono', monospace",
              }}>TIME</span>
            )}
            {layer.isTimeLane && (
              <span style={{
                fontSize: 8, letterSpacing: 2, padding: "2px 6px",
                border: `1px solid ${T.time}88`,
                background: `${T.time}25`,
                borderRadius: 2, color: T.time,
                fontFamily: "'Share Tech Mono', monospace",
                boxShadow: `0 0 6px ${T.time}44`,
                animation: `timepulse 2s ease-in-out infinite`,
              }}>NEW LANE</span>
            )}
          </div>

          {/* Expand arrow */}
          <div style={{ padding: "0 12px", color: isSelected ? c : T.muted, fontSize: 14, transition: "transform 0.25s, color 0.25s", transform: isSelected ? "rotate(90deg)" : "rotate(0)" }}>›</div>
        </div>
      </button>

      {/* Expanded TIME integration detail */}
      <div style={{ overflow: "hidden", maxHeight: isSelected ? 200 : 0, transition: "max-height 0.35s cubic-bezier(0.4,0,0.2,1)" }}>
        <div style={{
          margin: "4px 0 4px 3px", padding: "12px 16px",
          border: `1px solid ${T.time}33`, borderRadius: 3,
          background: `${T.time}08`,
        }}>
          <div style={{ fontSize: 9, color: T.time, letterSpacing: 3, marginBottom: 6 }}>TIME INTEGRATION POINT</div>
          <div style={{ fontSize: 11, color: "#aabbcc", lineHeight: 1.7, fontFamily: "'Share Tech Mono', monospace" }}>
            {layer.timeIntegration}
          </div>
        </div>
      </div>
    </div>
  );
}

function PillarPanel({ pillar, selected, onSelect }) {
  const isSelected = selected === pillar.id;
  const c = pillar.color;

  return (
    <div style={{ marginBottom: 8 }}>
      <button
        onClick={() => onSelect(isSelected ? null : pillar.id)}
        style={{ width: "100%", background: "transparent", border: "none", padding: 0, cursor: "pointer", textAlign: "left" }}
      >
        <div style={{
          display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
          border: `1px solid ${isSelected ? c + "88" : c + "33"}`,
          borderRadius: 3,
          background: isSelected ? `${c}12` : `${c}06`,
          boxShadow: isSelected ? `0 0 12px ${c}33` : "none",
          transition: "all 0.25s",
        }}>
          <span style={{ fontSize: 18, color: c }}>{pillar.icon}</span>
          <span style={{ fontSize: 9, letterSpacing: 2, color: isSelected ? c : c + "aa", fontFamily: "'Share Tech Mono', monospace", flex: 1 }}>
            {pillar.label}
          </span>
          <span style={{ fontSize: 9, color: c, opacity: 0.6 }}>{pillar.entries.length} ENTRIES</span>
          <span style={{ fontSize: 14, color: c, transform: isSelected ? "rotate(90deg)" : "rotate(0)", display: "inline-block", transition: "transform 0.25s" }}>›</span>
        </div>
      </button>

      <div style={{ overflow: "hidden", maxHeight: isSelected ? 400 : 0, transition: "max-height 0.4s cubic-bezier(0.4,0,0.2,1)" }}>
        <div style={{ padding: "10px 14px", border: `1px solid ${c}22`, borderRadius: 3, background: `${c}06`, margin: "3px 0 3px 3px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5px 12px" }}>
            {pillar.entries.map((e, i) => (
              <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 6 }}>
                <span style={{ width: 4, height: 4, borderRadius: "50%", background: c, flexShrink: 0, marginTop: 5, boxShadow: `0 0 4px ${c}` }} />
                <span style={{ fontSize: 10, color: "#8899bb", lineHeight: 1.5, fontFamily: "'Share Tech Mono', monospace" }}>{e}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function TIMEDiagram() {
  const [selectedLayer, setSelectedLayer] = useState(null);
  const [selectedPillar, setSelectedPillar] = useState(null);
  const [tick, setTick] = useState(0);
  const [timeActive, setTimeActive] = useState(true);

  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ minHeight: "100vh", background: T.bg, fontFamily: "'Share Tech Mono', monospace", color: T.text, position: "relative", overflow: "hidden" }}>
      <style>{`
        @keyframes timepulse { 0%,100%{opacity:1;box-shadow:0 0 6px #FF2D7844} 50%{opacity:0.6;box-shadow:0 0 14px #FF2D78aa} }
        @keyframes flowin { 0%{stroke-dashoffset:100} 100%{stroke-dashoffset:0} }
        @keyframes scan { 0%{transform:translateY(-100%)} 100%{transform:translateY(100vh)} }
        ::-webkit-scrollbar{width:3px} ::-webkit-scrollbar-track{background:#03050e} ::-webkit-scrollbar-thumb{background:#3a4f66;border-radius:2px}
      `}</style>

      {/* Grid */}
      <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", backgroundImage: `linear-gradient(${T.time}06 1px,transparent 1px),linear-gradient(90deg,${T.time}06 1px,transparent 1px)`, backgroundSize: "44px 44px" }} />
      {/* Scanline */}
      <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", background: "repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,0.035) 3px,rgba(0,0,0,0.035) 4px)" }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1200, margin: "0 auto", padding: "28px 16px" }}>

        {/* ── Header ── */}
        <div style={{ marginBottom: 28, display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div style={{ borderLeft: `3px solid ${T.time}`, paddingLeft: 16 }}>
            <div style={{ fontSize: 9, letterSpacing: 5, color: T.time, opacity: 0.6, marginBottom: 4 }}>AAC ECOSYSTEM — ARCHITECTURE REFERENCE</div>
            <h1 style={{
              margin: 0, fontFamily: "'Orbitron', sans-serif",
              fontSize: "clamp(18px,3vw,30px)", fontWeight: 900, letterSpacing: 3,
              background: `linear-gradient(90deg, #fff 0%, ${T.time} 60%, #FF8C42 100%)`,
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>IA + TIME ARCHITECTURE</h1>
            <div style={{ fontSize: 9, color: T.muted, letterSpacing: 3, marginTop: 2 }}>
              THREAT INTELLIGENCE ML ENGINE — INTEGRATED PIPELINE VIEW
            </div>
          </div>

          {/* TIME status */}
          <div style={{
            padding: "10px 16px", border: `1px solid ${T.time}55`,
            borderRadius: 3, background: `${T.time}08`,
            display: "flex", alignItems: "center", gap: 12,
            boxShadow: `0 0 20px ${T.time}22`,
          }}>
            <div style={{
              width: 8, height: 8, borderRadius: "50%", background: T.time,
              boxShadow: `0 0 ${8 + Math.sin(tick * 0.08) * 6}px ${T.time}`,
            }} />
            <div>
              <div style={{ fontSize: 10, color: T.time, letterSpacing: 3 }}>TIME ENGINE</div>
              <div style={{ fontSize: 8, color: T.muted, letterSpacing: 2, marginTop: 2 }}>THREAT INTELLIGENCE ML — ACTIVE</div>
            </div>
          </div>
        </div>

        {/* ── Main layout ── */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, alignItems: "start" }}>

          {/* ── LEFT: IA Pipeline with TIME integration points ── */}
          <div>
            <div style={{ fontSize: 9, letterSpacing: 4, color: T.muted, marginBottom: 10, paddingBottom: 8, borderBottom: `1px solid ${T.border}` }}>
              IA PIPELINE — CLICK LAYER TO SEE TIME INTEGRATION
            </div>

            {IA_LAYERS.map((layer, i) => (
              <div key={layer.key}>
                <LayerRow layer={layer} selected={selectedLayer} onSelect={setSelectedLayer} tick={tick} />
                {/* Connector */}
                {i < IA_LAYERS.length - 1 && (
                  <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "0 0 0 14px", margin: "1px 0" }}>
                    <div style={{ width: 2, height: 8, background: `linear-gradient(${layer.color}, ${IA_LAYERS[i + 1].color})`, opacity: 0.4 }} />
                    {layer.isTimeLane && (
                      <div style={{ fontSize: 8, color: T.time, letterSpacing: 2, opacity: 0.7 }}>← TIME FEEDS HERE</div>
                    )}
                  </div>
                )}
              </div>
            ))}

            {/* Model lanes detail */}
            <div style={{ marginTop: 16, padding: "14px", border: `1px solid ${T.border}`, borderRadius: 3, background: "rgba(255,255,255,0.01)" }}>
              <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 12 }}>LAYER 04 — MODEL LANES</div>
              {MODEL_LANES.map((lane) => (
                <div key={lane.label} style={{
                  display: "flex", alignItems: "center", gap: 8, marginBottom: 7,
                  padding: lane.isTime ? "6px 10px" : "4px 0",
                  border: lane.isTime ? `1px solid ${T.time}44` : "none",
                  borderRadius: lane.isTime ? 3 : 0,
                  background: lane.isTime ? `${T.time}10` : "transparent",
                  boxShadow: lane.isTime ? `0 0 10px ${T.time}22` : "none",
                  animation: lane.isTime ? "timepulse 2.5s ease-in-out infinite" : "none",
                }}>
                  <div style={{ width: 3, height: 20, background: lane.color, borderRadius: 2, flexShrink: 0, boxShadow: lane.isTime ? `0 0 6px ${lane.color}` : "none" }} />
                  <span style={{ fontSize: 10, letterSpacing: 2, color: lane.color, flex: 1 }}>
                    {lane.label}
                    {lane.isTime && <span style={{ marginLeft: 8, fontSize: 8, color: T.time, letterSpacing: 2 }}>★ NEW</span>}
                  </span>
                  <div style={{ width: 5, height: 5, borderRadius: "50%", background: lane.color, opacity: 0.8, boxShadow: lane.isTime ? `0 0 6px ${lane.color}` : "none" }} />
                </div>
              ))}
            </div>
          </div>

          {/* ── RIGHT: TIME Knowledge Base ── */}
          <div>
            <div style={{ fontSize: 9, letterSpacing: 4, color: T.muted, marginBottom: 10, paddingBottom: 8, borderBottom: `1px solid ${T.border}` }}>
              TIME — KNOWLEDGE BASE PILLARS
            </div>

            {/* TIME overview card */}
            <div style={{
              padding: "16px", marginBottom: 12,
              border: `1px solid ${T.time}55`, borderRadius: 3,
              background: `${T.time}07`,
              boxShadow: `0 0 24px ${T.time}18`,
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <div style={{ fontFamily: "'Orbitron', sans-serif", fontSize: 16, fontWeight: 900, color: T.time, letterSpacing: 4 }}>TIME</div>
                <div style={{ fontSize: 9, color: T.muted, letterSpacing: 2, flex: 1 }}>THREAT INTELLIGENCE ML ENGINE</div>
              </div>

              <div style={{ fontSize: 11, color: "#8899bb", lineHeight: 1.7, marginBottom: 12 }}>
                A specialized ML model embedded within the IA Orchestrator as a dedicated model lane. Not a standalone AV scanner — a living intelligence oracle trained on decades of platform history and threat evolution. Influences every IA response when threat context is present.
              </div>

              {/* Stats grid */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
                {[
                  ["PLATFORM ERAS", "12+"],
                  ["MALWARE FAMILIES", "100K+"],
                  ["BEHAVIORAL SIGS", "5M+"],
                ].map(([k, v]) => (
                  <div key={k} style={{ textAlign: "center", padding: "8px", border: `1px solid ${T.time}33`, borderRadius: 2, background: `${T.time}08` }}>
                    <div style={{ fontSize: 16, fontWeight: 700, color: T.time, fontFamily: "'Orbitron', sans-serif" }}>{v}</div>
                    <div style={{ fontSize: 8, color: T.muted, letterSpacing: 1, marginTop: 3 }}>{k}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Three pillars */}
            {TIME_PILLARS.map(pillar => (
              <PillarPanel key={pillar.id} pillar={pillar} selected={selectedPillar} onSelect={setSelectedPillar} />
            ))}

            {/* Threat score output */}
            <div style={{ marginTop: 12, padding: "14px", border: `1px solid ${T.ia.evaluate.color}44`, borderRadius: 3, background: `${T.ia.evaluate.color}07` }}>
              <div style={{ fontSize: 9, letterSpacing: 3, color: T.ia.evaluate.color, marginBottom: 10 }}>LAYER 05 — TIME OUTPUT TO EVALUATOR</div>
              {[
                ["threat_score", "0.0 – 1.0", "Primary threat confidence", T.time],
                ["anomaly_score", "0.0 – 1.0", "Behavioral deviation from baseline", "#FF8C42"],
                ["platform_match", "string", "Nearest historical platform profile", "#FFD700"],
                ["malware_lineage", "string[]", "Matched malware family lineage chain", "#FF6B9D"],
                ["signature_hits", "int", "Count of behavioral signature matches", "#4ECDC4"],
                ["override_confidence", "bool", "Threat score overrides evaluator floor", T.time],
              ].map(([field, type, desc, c]) => (
                <div key={field} style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 8, paddingBottom: 8, borderBottom: `1px solid ${T.border}` }}>
                  <div style={{ minWidth: 140 }}>
                    <div style={{ fontSize: 9, color: c, letterSpacing: 1 }}>{field}</div>
                    <div style={{ fontSize: 8, color: T.muted }}>{type}</div>
                  </div>
                  <div style={{ fontSize: 9, color: "#8899bb", lineHeight: 1.5 }}>{desc}</div>
                </div>
              ))}
            </div>

            {/* Cross-platform coverage */}
            <div style={{ marginTop: 12, padding: "14px", border: `1px solid ${T.border}`, borderRadius: 3 }}>
              <div style={{ fontSize: 9, letterSpacing: 3, color: T.muted, marginBottom: 10 }}>PLATFORM COVERAGE</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {["Windows 9x/ME", "Windows NT/XP", "Windows Vista/7", "Windows 8/8.1", "Windows 10/11", "macOS PPC", "macOS Intel", "macOS Apple Silicon", "Linux x86", "Linux x86-64", "Linux ARM", "Debian/Ubuntu", "RHEL/CentOS", "Arch/Gentoo", "Android Linux", "Embedded/IoT", "BSD variants", "DOS/Win16"].map(p => (
                  <span key={p} style={{
                    fontSize: 8, padding: "3px 7px",
                    border: `1px solid ${T.time}33`,
                    borderRadius: 2, color: "#6677aa",
                    background: `${T.time}08`,
                    letterSpacing: 1,
                  }}>{p}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Flow diagram ── */}
        <div style={{ marginTop: 20, padding: "16px", border: `1px solid ${T.border}`, borderRadius: 3, background: "rgba(255,255,255,0.01)" }}>
          <div style={{ fontSize: 9, letterSpacing: 4, color: T.muted, marginBottom: 14 }}>TIME SIGNAL FLOW WITHIN IA PIPELINE</div>
          <div style={{ display: "flex", alignItems: "center", gap: 0, overflowX: "auto" }}>
            {[
              { label: "INPUT\nINGESTION", sub: "file hash / PE header / process tree", color: T.ia.input.color },
              { label: "INTENT\nCLASSIFY", sub: "SECURITY_THREAT domain", color: T.ia.intent.color },
              { label: "PROMPT\nINJECT", sub: "threat context in all prompts", color: T.ia.prompt.color },
              { label: "TIME\nINFERENCE", sub: "dedicated model lane fires", color: T.time },
              { label: "THREAT\nSCORE", sub: "evaluator ingests TIME output", color: T.ia.evaluate.color },
              { label: "ALERT\nDISPATCH", sub: "ACTION_SECURITY_ALERT intent", color: T.ia.aac.color },
            ].map((step, i, arr) => (
              <div key={i} style={{ display: "flex", alignItems: "center", flex: 1, minWidth: 0 }}>
                <div style={{
                  flex: 1, padding: "10px 8px", textAlign: "center",
                  border: `1px solid ${step.color}55`,
                  borderRadius: 3, background: `${step.color}08`,
                  minWidth: 0,
                }}>
                  <div style={{ fontSize: step.color === T.time ? 11 : 9, fontWeight: 700, color: step.color, letterSpacing: 2, lineHeight: 1.3, whiteSpace: "pre-line", fontFamily: "'Orbitron', sans-serif" }}>{step.label}</div>
                  <div style={{ fontSize: 8, color: T.muted, marginTop: 4, lineHeight: 1.4 }}>{step.sub}</div>
                </div>
                {i < arr.length - 1 && (
                  <div style={{ width: 20, textAlign: "center", color: step.color, opacity: 0.5, fontSize: 14, flexShrink: 0 }}>›</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: 20, paddingTop: 12, borderTop: `1px solid ${T.border}`, display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
          <span style={{ fontSize: 8, color: T.muted, letterSpacing: 3 }}>ANDROID AUTO COMMERCIAL ECOSYSTEM</span>
          <span style={{ fontSize: 8, color: T.muted, letterSpacing: 2 }}>IA + TIME ARCHITECTURE v0.1</span>
        </div>
      </div>
    </div>
  );
}
